function cmp = compare_baseline_vs_green(scenario, doPlot)

    if nargin < 1 || isempty(scenario), scenario = 'slow_rise'; end
    if nargin < 2, doPlot = false; end

    cmp = struct();
    cmp.scenario = scenario;
    cmp.ok = false;

    try
        seed = getfield_or_seed(scenario);

        pBase = get_params(scenario);
        pBase.energy_adaptive_enabled = false;

        pGreen = get_params(scenario);
        pGreen.energy_adaptive_enabled = true;

        rng(seed);
        rBase  = main_flood_monitoring_system_core(pBase);
        rng(seed);
        rGreen = main_flood_monitoring_system_core(pGreen);

        E_base  = rBase.energyUsedJ(end);
        E_green = rGreen.energyUsedJ(end);
        pctSaved = 100 * (E_base - E_green) / max(E_base, eps);

        t = rBase.time;
        truth = trueWaterLevel(t, pBase.scenario, pBase.rise_rate);

        rmseBase  = sqrt(mean((rBase.waterLevelKalman  - truth).^2));
        rmseGreen = sqrt(mean((rGreen.waterLevelKalman - truth).^2));

        band = max(pBase.levelFlood - 0.5, 0.5);
        qualityBase  = 100 * max(0, 1 - rmseBase  / band);
        qualityGreen = 100 * max(0, 1 - rmseGreen / band);
        qualityDelta = qualityGreen - qualityBase;

        alarmBase_t  = firstAlarmTime(rBase);
        alarmGreen_t = firstAlarmTime(rGreen);
        if isnan(alarmBase_t) || isnan(alarmGreen_t)
            timingDeltaStr = 'n/a (no alarm fired in one or both runs)';
        else
            timingDeltaStr = sprintf('%.0fs (baseline) vs %.0fs (green)', alarmBase_t, alarmGreen_t);
        end

        kpiBase  = compute_kpi_summary(rBase,  pBase);
        kpiGreen = compute_kpi_summary(rGreen, pGreen);

        cmp.ok                = true;
        cmp.baseline.energyJ  = E_base;
        cmp.baseline.finalStatus = rBase.finalStatus;
        cmp.baseline.rmse_m   = rmseBase;
        cmp.baseline.quality_pct = qualityBase;
        cmp.baseline.kpi      = kpiBase;
        cmp.baseline.results  = rBase;

        cmp.green.energyJ     = E_green;
        cmp.green.finalStatus = rGreen.finalStatus;
        cmp.green.rmse_m      = rmseGreen;
        cmp.green.quality_pct = qualityGreen;
        cmp.green.kpi         = kpiGreen;
        cmp.green.results     = rGreen;

        cmp.kpi.energySavedPct  = pctSaved;
        cmp.kpi.qualityDeltaPct = qualityDelta;
        cmp.kpi.alarmTimingStr  = timingDeltaStr;

        printSummary(cmp);

        if doPlot
            try
                plotComparison(cmp);
            catch pe
                fprintf('[compare_baseline_vs_green] Plot skipped: %s\n', pe.message);
            end
        end

    catch e
        cmp.ok = false;
        cmp.error = e.message;
        fprintf('[compare_baseline_vs_green] FAILED (pipeline still safe): %s\n', e.message);
    end
end

function seed = getfield_or_seed(scenario)
    seed = sum(double(scenario)) + 1000;
end

function truth = trueWaterLevel(t, scenario, riseRate)
    baseLevel = 0.5;
    switch lower(scenario)
        case 'stable'
            truth = baseLevel * ones(size(t));
        case 'receding'
            truth = max(baseLevel + 3 + riseRate.*t, 0);
        case 'flash_flood'
            truth = baseLevel + 3./(1+exp(-0.25*(t-40)));
        otherwise
            truth = baseLevel + riseRate.*t;
    end
    truth = max(truth, 0);
end

function t0 = firstAlarmTime(r)
    idx = find(r.state >= 1, 1, 'first');
    if isempty(idx), t0 = NaN; else, t0 = r.time(idx); end
end

function printSummary(cmp)
    fprintf('\n================ BASELINE vs GREEN — %s ================\n', cmp.scenario);
    fprintf('%-28s %14s %14s\n', 'Metric', 'Baseline', 'Green');
    fprintf('%-28s %13.3f J %13.3f J\n', 'Energy used', cmp.baseline.energyJ, cmp.green.energyJ);
    fprintf('%-28s %13.2f %% %13.2f %%\n', 'Range/level accuracy', cmp.baseline.quality_pct, cmp.green.quality_pct);
    fprintf('%-28s %13.3f m %13.3f m\n', 'RMSE vs ground truth', cmp.baseline.rmse_m, cmp.green.rmse_m);
    fprintf('%-28s %13s %13s\n', 'Final status', cmp.baseline.finalStatus, cmp.green.finalStatus);
    fprintf('%-28s %13.2f %% %13.2f %%\n', 'CFAR detection-rate proxy', cmp.baseline.kpi.detectionRatePct, cmp.green.kpi.detectionRatePct);
    fprintf('%-28s %13.3f m %13.3f m\n', 'Forecast MAE (30s horizon)', cmp.baseline.kpi.forecastMAE_m, cmp.green.kpi.forecastMAE_m);
    fprintf('%-28s %12.1f dB %12.1f dB\n', 'Mean SNR', cmp.baseline.kpi.snrMean_dB, cmp.green.kpi.snrMean_dB);
    fprintf('%-28s %13.1f %% %13.1f %%\n', 'Time in Mode 2 (track)', cmp.baseline.kpi.dutyMode2Pct, cmp.green.kpi.dutyMode2Pct);
    fprintf('-------------------------------------------------------------------\n');
    fprintf('PAIRED KPI  ->  Energy saved: %+.1f %%   |   Quality change: %+.2f pct-pts\n', ...
        cmp.kpi.energySavedPct, cmp.kpi.qualityDeltaPct);
    fprintf('Alarm timing: %s\n', cmp.kpi.alarmTimingStr);
    fprintf('=====================================================================\n\n');
end

function plotComparison(cmp)
    rBase = cmp.baseline.results; rGreen = cmp.green.results;

    f = figure('Name','Baseline vs Green Radar','Color','w','Position',[100 100 1000 650]);

    subplot(2,1,1);
    plot(rBase.time, rBase.energyUsedJ, 'r-', 'LineWidth', 1.8); hold on;
    plot(rGreen.time, rGreen.energyUsedJ, 'g-', 'LineWidth', 1.8);
    grid on;
    title(sprintf('Cumulative Energy — %s scenario (Energy saved: %+.1f%%)', ...
        cmp.scenario, cmp.kpi.energySavedPct));
    xlabel('Time (s)'); ylabel('Cumulative energy (J)');
    legend('Baseline (fixed duty)','Green (adaptive duty)','Location','northwest');

    subplot(2,1,2);
    level0 = rBase.waterLevel(1);
    truth = level0 + (rBase.rateOfRise(2) >= 0)*0 + 0;
    plot(rBase.time, rBase.waterLevelKalman, 'r--', 'LineWidth', 1.4); hold on;
    plot(rGreen.time, rGreen.waterLevelKalman, 'g--', 'LineWidth', 1.4);
    grid on;
    title(sprintf('Water Level Estimate vs Ground Truth (Quality delta: %+.2f pct-pts)', ...
        cmp.kpi.qualityDeltaPct));
    xlabel('Time (s)'); ylabel('Water level (m)');
    legend('Baseline estimate','Green estimate','Location','northwest');

    sgtitle('Baseline (conventional, fixed-duty) vs Green (adaptive duty-cycling) — paired efficiency/quality KPIs');
end
