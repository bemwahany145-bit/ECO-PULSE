function [tx_signal, tx_matrix, meta_tx] = signal_generation(mode, params)

    if nargin < 2, params = get_params(); end
    if nargin < 1, mode = 1; end

    fs   = params.fs;
    PRI  = params.pulse_repetition_interval;
    Np   = params.num_pulses;
    duty = params.duty_cycle;
    Tp   = duty * PRI;
    Lp   = max(1, round(Tp * fs));
    Ls   = round((PRI - Tp) * fs);

    switch mode
        case 1
            N = params.zc_length;
            u = params.zc_root;
            n = (0:N-1)';
            zc = exp(-1j * pi * u * n .* (n+1) / N);
            if N >= Lp
                pulse = zc(1:Lp);
            else
                pulse = [zc; zeros(Lp-N,1)];
            end
            codeInfo = sprintf('Zadoff-Chu N=%d u=%d', N, u);
        otherwise
            t = (0:Lp-1)' / fs;
            B = params.chirp_bandwidth;
            k = B / Tp;
            pulse = exp(1j*pi*k*t.^2);
            codeInfo = sprintf('LFM B=%.1fMHz Tp=%.1fus', B/1e6, Tp*1e6);
    end

    switch lower(params.code_type)
        case 'barker'
            bar = barker_code(params.barker_length);
            pulse = expand_code(bar, Lp);
            codeInfo = [codeInfo sprintf(' + Barker-%d', params.barker_length)];
        case 'frank'
            fr = frank_code(params.frank_M);
            pulse = expand_code(fr, Lp);
            codeInfo = [codeInfo sprintf(' + Frank-%d', params.frank_M^2)];
        otherwise
    end

    win = select_window(params.window_type, Lp, params.window_param);
    pulse = pulse .* win;
    pulse = pulse / max(abs(pulse)+eps);

    persistent hop_counter
    if isempty(hop_counter), hop_counter = 0; end
    if params.frequency_agility
        hopSet = params.freq_hop_set(:);
        df = hopSet(mod(hop_counter, numel(hopSet)) + 1);
        hop_counter = hop_counter + 1;
    else
        df = 0;
    end
    meta_tx.f_pulse = repmat(df, Np, 1);
    single_pulse = [pulse; zeros(Ls,1)];
    tx_matrix = zeros(Lp+Ls, Np);
    nAxis = (0:Lp+Ls-1)' / fs;
    hop_phasor = exp(1j*2*pi*df*nAxis);
    for m = 1:Np
        tx_matrix(:,m) = single_pulse .* hop_phasor;
    end
    tx_signal = tx_matrix(:);

    if params.bursts_per_frame > 1
        gap = zeros(round(params.gap_between_bursts*fs),1);
        tx_signal_burst = tx_signal;
        for b = 2:params.bursts_per_frame
            tx_signal = [tx_signal; gap; tx_signal_burst];
        end
    end

    if params.enable_passband && params.f0 > 0
        tAll = (0:length(tx_signal)-1).' / fs;
        tx_signal = real(tx_signal .* exp(1j*2*pi*params.f0*tAll));
    end

    meta_tx.mode    = mode;
    meta_tx.code    = codeInfo;
    meta_tx.window  = params.window_type;
    meta_tx.passband = params.enable_passband;
end

function w = select_window(type, L, par)
    if L < 4
        w = ones(L,1);
        return;
    end
    switch lower(type)
        case 'hann'
            if exist('hann','file'), w = hann(L);
            else, w = safe_hann(L); end
        case 'hamming'
            if exist('hamming','file'), w = hamming(L);
            else, w = safe_hamming(L); end
        case 'kaiser'
            if exist('kaiser','file'), w = kaiser(L, max(par,1));
            else, w = safe_hann(L); end
        case 'chebwin'
            if exist('chebwin','file'), w = chebwin(L, par);
            else, w = safe_hann(L); end
        case 'taylorwin'
            if exist('taylorwin','file'), w = taylorwin(L, 4, -par);
            else, w = safe_hann(L); end
        otherwise,         w = ones(L,1);
    end
    w = w(:);
end

function w = safe_hann(L)
    n = (0:L-1).';
    w = 0.5 - 0.5*cos(2*pi*n / max(L-1,1));
end
function w = safe_hamming(L)
    n = (0:L-1).';
    w = 0.54 - 0.46*cos(2*pi*n / max(L-1,1));
end

function c = barker_code(L)
    switch L
        case 2,  c = [1 -1];
        case 3,  c = [1 1 -1];
        case 4,  c = [1 1 -1 1];
        case 5,  c = [1 1 1 -1 1];
        case 7,  c = [1 1 1 -1 -1 1 -1];
        case 11, c = [1 1 1 -1 -1 -1 1 -1 -1 1 -1];
        case 13, c = [1 1 1 1 1 -1 -1 1 1 -1 1 -1 1];
        otherwise
            warning('Barker length %d not standard; using 13.', L);
            c = [1 1 1 1 1 -1 -1 1 1 -1 1 -1 1];
    end
    c = c(:);
end

function c = frank_code(M)
    n = (0:M-1); k = (0:M-1);
    [N,K] = meshgrid(n,k);
    Phi = 2*pi*N.*K/M;
    c = exp(1j*Phi); c = c(:);
end

function out = expand_code(code, L)
    idx = min(ceil((1:L)' * numel(code) / L), numel(code));
    out = code(idx);
end
