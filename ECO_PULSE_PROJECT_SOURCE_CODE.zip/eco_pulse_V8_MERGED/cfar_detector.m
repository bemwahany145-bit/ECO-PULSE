function mask = cfar_detector(profile, type, Pfa, Ntrain, Nguard)

    if nargin < 2, type   = 'CA';  end
    if nargin < 3, Pfa    = 1e-6;  end
    if nargin < 4, Ntrain = 32;    end
    if nargin < 5, Nguard = 4;     end

    switch upper(type)
        case {'2STAGE','AUTO','ADAPTIVE'}
            mask = cfar_2stage(profile, Pfa, Ntrain, Nguard);
        case 'CA'
            mask = cfar_ca(profile, Pfa, Ntrain, Nguard);
        case 'OS'
            mask = cfar_os(profile, Pfa, Ntrain, Nguard);
        otherwise
            error('Unknown CFAR type: %s', type);
    end
end

function mask = cfar_2stage(profile, Pfa, Ntrain, Nguard)
    profile = profile(:);
    N = length(profile);
    amp = abs(profile);

    mask_s1 = cfar_ca(profile, min(Pfa * 10, 0.5), Ntrain, Nguard);

    mu = mean(amp) + eps;
    VI = std(amp) / mu;

    if VI < 0.5
        mask = cfar_ca(profile, Pfa, Ntrain, Nguard);

    elseif VI < 1.5
        mask_os = cfar_os(profile, Pfa, Ntrain, Nguard, 0.75);
        mask_ca_mod = cfar_ca(profile, Pfa, Ntrain, Nguard);
        if sum(mask_os) <= sum(mask_ca_mod)
            mask = mask_os;
        else
            mask = mask_ca_mod;
        end

    else
        mask_ca = cfar_ca(profile, Pfa, Ntrain, Nguard);

        valid = find(mask_s1);
        mask_local = false(N,1);
        if ~isempty(valid)
            local_mask = cfar_os_at(profile, valid, Pfa, Ntrain, Nguard, 0.95);
            mask_local(valid(local_mask)) = true;
        end

        if sum(mask_local) <= sum(mask_ca)
            mask = mask_local;
        else
            mask = mask_ca;
        end
    end

    mask = mask(:)';
end

function passed = cfar_os_at(profile, indices, Pfa, Ntrain, Nguard, k_frac)
    x = abs(profile(:)).^2;
    N = length(x);
    half = round(Ntrain/2) + Nguard;
    k = max(1, round(k_frac * Ntrain));
    alpha = k * (Pfa^(-1/k) - 1);
    min_noise = 0.01 * mean(x(x > 0) + eps);
    if isnan(min_noise) || min_noise <= 0, min_noise = eps; end

    passed = false(numel(indices),1);
    for ii = 1:numel(indices)
        idx = indices(ii);
        if idx > half && idx <= N - half
            cells = [x(idx-half : idx-Nguard-1); x(idx+Nguard+1 : idx+half)];
            cells = sort(cells, 'ascend');
            noise_est = max(cells(min(k,end)), min_noise);
            T = alpha * noise_est;
            passed(ii) = x(idx) > T;
        else
            passed(ii) = true;
        end
    end
end

function mask = cfar_ca(profile, Pfa, Ntrain, Nguard)
    x    = abs(profile(:)).^2;
    N    = length(x);
    mask = false(N,1);

    half = round(Ntrain/2) + Nguard;
    if N < 2*half + 1, return; end

    min_noise = 0.01 * mean(x(x > 0) + eps);
    if isnan(min_noise) || min_noise <= 0, min_noise = eps; end

    alpha = Ntrain * (Pfa^(-1/Ntrain) - 1);
    for idx = (half+1) : (N-half)
        lead = x(idx - half      : idx - Nguard - 1);
        lag  = x(idx + Nguard + 1 : idx + half);
        noise_est = max(mean([lead; lag]), min_noise);
        T = alpha * noise_est;
        if x(idx) > T
            mask(idx) = true;
        end
    end
    mask = mask(:)';
end

function mask = cfar_os(profile, Pfa, Ntrain, Nguard, k_frac)
    if nargin < 5, k_frac = 0.75; end
    x    = abs(profile(:)).^2;
    N    = length(x);
    mask = false(N,1);

    half = round(Ntrain/2) + Nguard;
    if N < 2*half + 1, return; end

    min_noise = 0.01 * mean(x(x > 0) + eps);
    if isnan(min_noise) || min_noise <= 0, min_noise = eps; end

    k     = max(1, round(k_frac * Ntrain));
    alpha = k * (Pfa^(-1/k) - 1);
    for idx = (half+1) : (N-half)
        cells = [x(idx-half : idx-Nguard-1);
                 x(idx+Nguard+1 : idx+half)];
        cells     = sort(cells, 'ascend');
        noise_est = max(cells(min(k,end)), min_noise);
        T = alpha * noise_est;
        if x(idx) > T
            mask(idx) = true;
        end
    end
    mask = mask(:)';
end
