function [rx_signal, meta] = environment_model(tx_signal, params, t)

    persistent wave_state

    tx_signal = tx_signal(:);
    N = length(tx_signal);

    req = {'mountHeight','samplesPerMeter','SNR_dB','clutter_dB','multipath'};
    for i = 1:numel(req)
        if ~isfield(params,req{i})
            error('environment_model: missing param %s',req{i});
        end
    end

    riseRate  = getfield_or(params,'rise_rate',0.025);
    baseLevel = 0.5;
    if strcmpi(params.scenario,'stable')
        waterLevel = baseLevel;
    elseif strcmpi(params.scenario,'receding')
        waterLevel = max(baseLevel + 3 + riseRate*t, 0);
    elseif strcmpi(params.scenario,'flash_flood')
        waterLevel = baseLevel + 3./(1+exp(-0.25*(t-40)));
    else
        waterLevel = baseLevel + riseRate*t;
    end
    waterLevel = max(waterLevel, 0);

    U10 = getfield_or(params,'wind_speed_U10',6);
    [eta, vz, wave_state] = surface_wave_sample(params.wave_spectrum, U10, t, wave_state);
    waterLevel_inst = waterLevel + eta;
    currentRange    = params.mountHeight - waterLevel_inst;
    if currentRange <= 0, currentRange = 0.1; end

    delay_samples = round(currentRange * params.samplesPerMeter);
    attenuation   = 1 / (currentRange^2 + 1);

    rainRate = getfield_or(params,'rain_rate_mmph',0);
    if rainRate > 0
        gamma_dB_per_km = params.rain_k * rainRate^params.rain_alpha_exp;
        path_km = 2*currentRange/1000;
        rain_loss = 10^(-gamma_dB_per_km*path_km/20);
        attenuation = attenuation * rain_loss;
    end

    rx_signal = zeros(N,1);
    if delay_samples < N
        rx_signal(delay_samples+1:end) = attenuation * tx_signal(1:N-delay_samples);
    end

    if getfield_or(params,'enable_doppler',true)
        lambda = getfield_or(params,'lambda',3e8/24e9);
        fd = 2*vz / lambda;
        n = (0:N-1).';
        dopplerPhase = exp(1j*2*pi*fd*n/params.fs);
        rx_signal = rx_signal .* dopplerPhase;
    end

    if params.multipath
        refl1 = 0.15;
        extra1 = round(0.25*delay_samples);
        tot1 = delay_samples + extra1;
        if tot1 < N
            rx_signal(tot1+1:end) = rx_signal(tot1+1:end) + ...
                attenuation*refl1*tx_signal(1:N-tot1);
        end
        if getfield_or(params,'bank_multipath',true)
            bankD     = getfield_or(params,'bank_offset_m',8);
            bankRange = currentRange + bankD;
            bankDelay = round(bankRange*params.samplesPerMeter);
            reflBank  = 0.08;
            if bankDelay < N
                rx_signal(bankDelay+1:end) = rx_signal(bankDelay+1:end) + ...
                    (attenuation*reflBank) * tx_signal(1:N-bankDelay);
            end
        end
    end

    if getfield_or(params,'raytracing',false) && exist('ray_tracing','file')
        try
            rx_signal = ray_tracing(rx_signal, tx_signal, currentRange, params);
        catch ME
            warning('ray_tracing failed: %s',ME.message);
        end
    end

    signal_power = mean(abs(rx_signal).^2);
    if signal_power == 0, signal_power = 1e-12; end

    clutter_power = signal_power * 10^(params.clutter_dB/10);
    clutter = sqrt(clutter_power/2) * (randn(N,1) + 1j*randn(N,1));

    noise_power = signal_power / 10^(params.SNR_dB/10);

    if getfield_or(params,'colored_noise',false)
        alpha = params.color_alpha;
        w = sqrt(noise_power/2) * (randn(N,1) + 1j*randn(N,1));
        noise = filter(1,[1 -alpha], w);
        noise = noise * sqrt(noise_power / (mean(abs(noise).^2) + eps));
    else
        noise = sqrt(noise_power/2) * (randn(N,1) + 1j*randn(N,1));
    end

    rx_signal = rx_signal + clutter + noise;

    meta = struct();
    meta.waterLevel    = waterLevel;
    meta.waterSurface  = waterLevel_inst;
    meta.range         = currentRange;
    meta.delay_samples = delay_samples;
    meta.delaySamples  = delay_samples;
    meta.attenuation   = attenuation;
    meta.waterState    = scenarioState(params.scenario, riseRate);
    meta.SNR_actual_dB = 10*log10(signal_power/noise_power + eps);
    meta.surface_vz    = vz;
    meta.wind_U10      = U10;
    meta.rainRate      = rainRate;
end

function v = getfield_or(s,f,def)
    if isfield(s,f), v = s.(f); else, v = def; end
end

function st = scenarioState(scen, r)
    if strcmpi(scen,'receding'),   st = 'falling';
    elseif r > 0.05,               st = 'flash';
    elseif r > 0.01,               st = 'rising';
    else,                          st = 'stable';
    end
end

function [eta, vz, state] = surface_wave_sample(spectrum, U10, t, state)
    if isempty(state) || ~isfield(state,'spectrum') || ~strcmpi(state.spectrum, spectrum)
        state.spectrum = spectrum;
        Nw = 24;
        kmin = 0.05; kmax = 6;
        k = linspace(kmin, kmax, Nw);
        switch lower(spectrum)
            case 'pierson_moskowitz'
                g = 9.81;
                w = sqrt(g*k);
                alpha_pm = 8.1e-3;
                beta_pm  = 0.74;
                wp = g/max(U10, 1);
                S  = alpha_pm*g^2./(w.^5).*exp(-beta_pm*(wp./w).^4);
            case 'elfouhaily'
                g  = 9.81;
                w  = sqrt(g*k);
                wp = 0.855*g/max(U10,1);
                S  = 0.005*(wp./w).^4 .* exp(-0.74*(wp./w).^4) ./ (w+eps);
            otherwise
                w = sqrt(9.81*k);
                S = zeros(size(k));
        end
        dk = k(2)-k(1);
        A  = sqrt(2*max(S,0)*dk);
        phi = 2*pi*rand(1,Nw);
        state.w = w; state.A = A; state.phi = phi; state.k = k;
    end
    eta_vec = state.A .* cos(state.w*t + state.phi);
    vz_vec  = -state.A .* state.w .* sin(state.w*t + state.phi);
    eta = sum(eta_vec);
    vz  = sum(vz_vec);
end
