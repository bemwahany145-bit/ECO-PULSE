function [score, state] = pro_anomaly_ae(features, state)
    if isempty(state) || ~isfield(state,'mu')
        state.mu    = zeros(4,1);
        state.sigma = ones(4,1);
        state.n     = 0;
    end
    x = [features.waterLevel; features.rateOfRise; ...
         features.snr; features.peakWidth];
    state.n = state.n + 1;
    mu_new = state.mu + (x - state.mu) / state.n;
    state.sigma = state.sigma + (x - state.mu) .* (x - mu_new);
    state.mu = mu_new;
    sd = sqrt(state.sigma / max(state.n-1, 1)) + 1e-6;
    z = (x - state.mu) ./ sd;
    score = min(1, sqrt(mean(z.^2)) / 5);
end
