function [LLR, flag] = pro_bayes_detector(features, LLR_prev, params)
    L0 = params.levelAlert;  s0 = 0.3;
    L1 = params.levelFlood;  s1 = 0.4;
    z  = features.waterLevel;
    logp1 = -0.5*((z-L1)/s1)^2 - log(s1);
    logp0 = -0.5*((z-L0)/s0)^2 - log(s0);
    LLR = LLR_prev + (logp1 - logp0);
    LLR = max(min(LLR, 50), -50);
    A = log(0.95/1e-3); B = log(0.05/(1-1e-3));
    flag = LLR > A;
    if LLR < B, LLR = 0; end
end
