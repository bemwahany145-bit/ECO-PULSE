function animate_flood_3d(results, params)

    figure('Name','Radar - 3D Flood Simulation (Enhanced)', ...
           'Position',[100 80 1500 900],'Color',[0.95 0.97 1]);

    ax = axes('Position',[0.06 0.08 0.62 0.85]);
    riverL = 140; riverW = 70;
    [X,Y] = meshgrid(linspace(-riverL/2,riverL/2,120), ...
                     linspace(-riverW/2,riverW/2,60));

    surf(ax, X, Y, -1.5*ones(size(X)),'FaceColor',[0.35 0.25 0.15], ...
         'EdgeColor','none'); hold(ax,'on');

    tx_pos = -riverL/2 + 18; ty_pos = 12; th = params.mountHeight;
    if getfield_or(params,'use_stl_radar',false) && exist(getfield_or(params,'stl_radar_file','tower.stl'),'file')
        try
            [F,V] = stlread(params.stl_radar_file);
            V(:,1) = V(:,1)+tx_pos; V(:,2) = V(:,2)+ty_pos;
            patch(ax,'Faces',F,'Vertices',V,'FaceColor',[0.2 0.2 0.25], ...
                  'EdgeColor','none','FaceLighting','gouraud');
        catch
            simple_tower(ax,tx_pos,ty_pos,th);
        end
    else
        simple_tower(ax,tx_pos,ty_pos,th);
    end

    levelX = tx_pos + 35;
    h_level = line(ax, [levelX levelX],[ty_pos ty_pos],[0 6], ...
                   'Color',[1 1 1],'LineWidth',5,'LineStyle','--');

    h_water = surf(ax, X, Y, results.waterLevel(1)*ones(size(X)), ...
        'FaceColor',[0 0.4 0.85],'EdgeColor','none','FaceAlpha',0.9);

    xlabel(ax,'River Length (m)'); ylabel(ax,'River Width (m)'); zlabel(ax,'Height (m)');
    title(ax,'Radar - Realistic 3D Flood Simulation','FontSize',16,'FontWeight','bold');
    view(ax,-40,35); axis(ax,'equal'); grid(ax,'on');
    lighting(ax,'gouraud'); camlight(ax,'headlight'); material(ax,'shiny');
    ax.ZLim=[-2 7]; ax.XLim=[-80 80]; ax.YLim=[-45 45];

    if getfield_or(params,'use_3d_fog',true)
        try
            set(ax,'Color',[0.87 0.9 0.95]);
            for zc = 0:0.5:5
                patch(ax,[-80 80 80 -80],[-45 -45 45 45],[zc zc zc zc], ...
                     [0.8 0.85 0.9],'FaceAlpha',0.03,'EdgeColor','none');
            end
        catch
        end
    end

    if getfield_or(params,'use_big_indicators',true)
        h_big_level = annotation('textbox',[0.7 0.83 0.27 0.10], ...
            'String','Level: --','FontSize',28,'FontWeight','bold', ...
            'BackgroundColor',[0.95 0.95 1],'EdgeColor',[0 0 0.5], ...
            'HorizontalAlignment','center');
        h_big_status = annotation('textbox',[0.7 0.71 0.27 0.10], ...
            'String','MONITORING','FontSize',24,'FontWeight','bold', ...
            'BackgroundColor',[0.85 1 0.85],'EdgeColor','k', ...
            'HorizontalAlignment','center');
        h_countdown = annotation('textbox',[0.7 0.62 0.27 0.07], ...
            'String','','FontSize',14,'FontWeight','bold', ...
            'BackgroundColor',[1 1 0.85],'EdgeColor','k', ...
            'HorizontalAlignment','center');
    else
        h_big_level = []; h_big_status = []; h_countdown = [];
    end

    rose_ax = polaraxes('Position',[0.72 0.28 0.25 0.30]);
    title(rose_ax,'Wave Direction Rose');
    if isfield(results,'waveDirs') && ~isempty(results.waveDirs)
        polarhistogram(rose_ax, results.waveDirs, 18,'FaceColor',[0.2 0.5 0.8]);
    else
        theta = (0:15:345)*pi/180;
        polarhistogram(rose_ax, theta, 'FaceColor',[0.6 0.7 0.9]);
    end

    h_status = annotation('textbox',[0.72 0.08 0.25 0.18], ...
        'String','Starting...','FontSize',12,'FontWeight','bold', ...
        'BackgroundColor',[0.95 1 0.95],'EdgeColor','k','LineWidth',2, ...
        'HorizontalAlignment','left');

    for k = 2:length(results.time)
        t  = results.time(k);
        wl = results.waterLevel(k);

        wave = 0.12*sin(2*pi*0.35*X + 7*t).*cos(2*pi*0.22*Y + 5*t) + ...
               0.05*sin(2*pi*0.8*X + 14*t);
        if wl >= params.levelAlert, wave = wave*2.5; end
        Z = wl + wave;
        set(h_water,'ZData',Z,'FaceColor',[0 0.35+0.15*(wl/3.5) 0.85]);
        set(h_level,'ZData',[0 wl+0.4]);

        if wl >= params.levelFlood
            st='[!!!] FLOOD RISK'; bg=[1 0.25 0.25];
        elseif wl >= params.levelAlert
            st='[!] ALERT';        bg=[1 0.75 0.15];
        else
            st='[OK] MONITORING';  bg=[0.85 1 0.85];
        end

        infoStr = sprintf('Time: %.1f s\nLevel: %.2f m\nRate: %.4f m/s\nSNR: %.1f dB\nStatus: %s', ...
            t, wl, safeGet(results,'rateOfRise',k,0), ...
            safeGet(results,'snr',k,0), st);
        set(h_status,'String',infoStr,'BackgroundColor',bg);

        if ~isempty(h_big_level)
            set(h_big_level,'String',sprintf('Level: %.2f m',wl));
            set(h_big_status,'String',st,'BackgroundColor',bg);
            if isfield(results,'timeRemaining')
                set(h_countdown,'String', ...
                    sprintf('Validation countdown: %.0f s', results.timeRemaining(k)));
            end
        end

        drawnow limitrate
        pause(0.025);
    end

    disp('[animate_flood_3d] finished.');
end

function simple_tower(ax,tx,ty,th)
    line(ax,[tx tx],[ty ty],[0 th],'Color',[0.1 0.1 0.1],'LineWidth',18);
    patch(ax,tx+[-3.5 3.5 3.5 -3.5],ty+[-2.5 -2.5 2.5 2.5], ...
          [th th th th],[0.1 0.1 0.25],'FaceAlpha',0.95);
end

function v = safeGet(r,f,k,d)
    if isfield(r,f) && length(r.(f))>=k, v = r.(f)(k); else, v = d; end
end

function v = getfield_or(s,f,d)
    if isfield(s,f), v=s.(f); else, v=d; end
end
