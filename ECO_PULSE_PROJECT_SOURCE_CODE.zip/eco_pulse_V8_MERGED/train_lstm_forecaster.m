function W = train_lstm_forecaster()
    warning('off','all');

    [X, Y] = gen_training_data([]);
    Nex = numel(X);

    allLvl = []; allRate = []; allRain = [];
    for k=1:Nex, allLvl=[allLvl, X{k}(1,:)]; allRate=[allRate, X{k}(2,:)]; allRain=[allRain, X{k}(3,:)]; end
    norm.mu_l = mean(allLvl); norm.sg_l = std(allLvl)+eps;
    norm.mu_r = mean(allRate); norm.sg_r = std(allRate)+eps;
    norm.mu_rain = mean(allRain); norm.sg_rain = std(allRain)+1e-3;

    nh = 6; nx = 3;
    rng(42);
    sc = 0.3;
    W.Wf = sc*randn(nh,nh+nx); W.bf = zeros(nh,1);
    W.Wi = sc*randn(nh,nh+nx); W.bi = zeros(nh,1);
    W.Wo = sc*randn(nh,nh+nx); W.bo = zeros(nh,1);
    W.Wc = sc*randn(nh,nh+nx); W.bc = zeros(nh,1);
    W.Wy = sc*randn(1,nh);     W.by = 0;

    Wt = W; Xseq_t = X{1}; Ytrue_t = Y(1);
    grads_t = lstm_backward_one(Xseq_t, Ytrue_t, Wt, norm);
    fns = fieldnames(Wt);
    fprintf('Gradient check (analytic vs numerical, relative error):\n');
    maxrelerr = 0;
    for fi = 1:numel(fns)
        f = fns{fi};
        Wp = Wt; Wm = Wt;
        sz = size(Wt.(f));
        for trial = 1:3
            idx = randi(numel(Wt.(f)));
            eps_ = 1e-5;
            Wp.(f)(idx) = Wt.(f)(idx) + eps_;
            Wm.(f)(idx) = Wt.(f)(idx) - eps_;
            [pp,~,~] = lstm_forecast_forward(Xseq_t, Wp, norm);
            [pm,~,~] = lstm_forecast_forward(Xseq_t, Wm, norm);
            Lp = 0.5*(pp-Ytrue_t)^2; Lm = 0.5*(pm-Ytrue_t)^2;
            num_grad = (Lp-Lm)/(2*eps_);
            an_grad = grads_t.(f)(idx);
            relerr = abs(num_grad-an_grad) / max(1e-6, abs(num_grad)+abs(an_grad));
            maxrelerr = max(maxrelerr, relerr);
            Wp.(f)(idx) = Wt.(f)(idx); Wm.(f)(idx) = Wt.(f)(idx);
        end
        fprintf('  %-4s max_relerr(3 samples so far)=%.2e\n', f, maxrelerr);
    end
    fprintf('Overall max relative error: %.2e %s\n', maxrelerr, ...
        merge_ok(maxrelerr));

    lr = 0.02;
    nIter = 400;
    Ntr = Nex;
    lossHist = zeros(1,nIter);
    for it = 1:nIter
        G = zero_grads(W);
        totLoss = 0;
        perm = randperm(Ntr, min(120,Ntr));
        for kk = 1:numel(perm)
            k = perm(kk);
            [g, loss] = lstm_backward_one(X{k}, Y(k), W, norm);
            totLoss = totLoss + loss;
            for fi=1:numel(fns)
                G.(fns{fi}) = G.(fns{fi}) + g.(fns{fi})/numel(perm);
            end
        end
        for fi=1:numel(fns)
            W.(fns{fi}) = W.(fns{fi}) - lr*G.(fns{fi});
        end
        lossHist(it) = totLoss/numel(perm);
        if mod(it,50)==0
            fprintf('iter %4d  meanLoss=%.5f\n', it, lossHist(it));
        end
    end

    errs = zeros(1,Nex);
    for k=1:Nex
        [p,~,~] = lstm_forecast_forward(X{k}, W, norm);
        errs(k) = p - Y(k);
    end
    fprintf('\nFinal training RMSE = %.4f m (over %d examples)\n', sqrt(mean(errs.^2)), Nex);

    save('-v7','lstm_weights.mat','W','norm');
    fprintf('Saved weights to lstm_weights.mat (current folder)\n');
    fprintf('Copy W and norm into lstm_weights_() inside pro_lstm_forecaster_v2.m to deploy.\n');
end

function s = merge_ok(e)
    if e < 1e-2, s = '(OK - backprop verified)'; else, s = '(WARNING - check backprop!)'; end
end

function G = zero_grads(W)
    fns = fieldnames(W);
    for fi=1:numel(fns), G.(fns{fi}) = zeros(size(W.(fns{fi}))); end
end

function [grads, loss] = lstm_backward_one(Xseq, Ytrue, W, norm)
    [pred, h_T, cache] = lstm_forecast_forward(Xseq, W, norm);
    [nx, T] = size(Xseq);
    nh = size(W.Wf,1);

    loss = 0.5*(pred - Ytrue)^2;
    dpred = (pred - Ytrue) * norm.sg_l;

    grads.Wy = dpred * h_T';
    grads.by = dpred;
    grads.Wf = zeros(size(W.Wf)); grads.bf = zeros(size(W.bf));
    grads.Wi = zeros(size(W.Wi)); grads.bi = zeros(size(W.bi));
    grads.Wo = zeros(size(W.Wo)); grads.bo = zeros(size(W.bo));
    grads.Wc = zeros(size(W.Wc)); grads.bc = zeros(size(W.bc));

    dh_next = (W.Wy' * dpred);
    dc_next = zeros(nh,1);

    for t = T:-1:1
        z = cache.z{t}; f=cache.f{t}; i=cache.i{t}; o=cache.o{t};
        g=cache.g{t}; c=cache.c{t}; cprev=cache.cprev{t};

        dh = dh_next;
        tanh_c = tanh(c);
        do_ = dh .* tanh_c .* o.*(1-o);
        dc = dh .* o .* (1 - tanh_c.^2) + dc_next;
        df = dc .* cprev .* f.*(1-f);
        di = dc .* g     .* i.*(1-i);
        dg = dc .* i     .* (1-g.^2);

        grads.Wf = grads.Wf + df*z'; grads.bf = grads.bf + df;
        grads.Wi = grads.Wi + di*z'; grads.bi = grads.bi + di;
        grads.Wo = grads.Wo + do_*z'; grads.bo = grads.bo + do_;
        grads.Wc = grads.Wc + dg*z'; grads.bc = grads.bc + dg;

        dz = W.Wf'*df + W.Wi'*di + W.Wo'*do_ + W.Wc'*dg;
        dh_next = dz(1:nh);
        dc_next = dc .* f;
    end
end
