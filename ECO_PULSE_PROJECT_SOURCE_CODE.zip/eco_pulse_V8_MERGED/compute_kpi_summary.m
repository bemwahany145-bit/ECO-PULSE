function kpi = compute_kpi_summary(results, params)

    kpi = struct();

    try
        if isfield(results,'cfarMaskHist') && ~isempty(results.cfarMaskHist)
            hitPerTick = any(results.cfarMaskHist, 2);
            kpi.detectionRatePct = 100 * mean(hitPerTick);
        elseif isfield(results,'detHitsCount') && isfield(results,'nTicksTotal') && results.nTicksTotal > 0
            kpi.detectionRatePct = 100 * results.detHitsCount / results.nTicksTotal;
        else
            kpi.detectionRatePct = NaN;
        end
    catch
        kpi.detectionRatePct = NaN;
    end

    try
        t = results.time;
        level0 = 0.5;
        truth = trueWaterLevel_local(t, params.scenario, params.rise_rate);
        idxTrueAlert = find(truth >= params.levelAlert, 1, 'first');
        idxConfirmed = find(results.state >= 1, 1, 'first');
        if isempty(idxTrueAlert) || isempty(idxConfirmed)
            kpi.alarmLatencyS = NaN;
        else
            kpi.alarmLatencyS = t(idxConfirmed) - t(idxTrueAlert);
        end
    catch
        kpi.alarmLatencyS = NaN;
    end

    try
        horizon_s = getfield_or_local(params,'forecast_horizon_s',30);
        dt        = getfield_or_local(params,'dt',1);
        shift     = round(horizon_s/dt);
        N = numel(results.time);
        if shift > 0 && shift < N
            fcst   = results.forecastLevel(1:N-shift);
            actual = results.waterLevel(1+shift:N);
            valid  = ~isnan(fcst) & ~isnan(actual);
            if any(valid)
                kpi.forecastMAE_m = mean(abs(fcst(valid) - actual(valid)));
            else
                kpi.forecastMAE_m = NaN;
            end
        else
            kpi.forecastMAE_m = NaN;
        end
    catch
        kpi.forecastMAE_m = NaN;
    end

    try
        kpi.dutyMode1Pct = 100 * mean(results.state == 0);
        kpi.dutyMode2Pct = 100 * mean(results.state >= 1);
    catch
        kpi.dutyMode1Pct = NaN; kpi.dutyMode2Pct = NaN;
    end

    try
        kpi.snrMean_dB = mean(results.snr);
        kpi.snrMin_dB  = min(results.snr);
        kpi.snrMax_dB  = max(results.snr);
    catch
        kpi.snrMean_dB = NaN; kpi.snrMin_dB = NaN; kpi.snrMax_dB = NaN;
    end

    try
        if isfield(results,'batteryPct'), bp = results.batteryPct;
        else,                             bp = results.battery;
        end
        if isfield(results,'energyUsedJ'), eJ = results.energyUsedJ;
        else,                              eJ = results.energy;
        end
        durationS   = max(results.time(end) - results.time(1), getfield_or_local(params,'dt',1));
        avgPowerW   = eJ(end) / durationS;
        capacityWh  = getfield_or_local(params,'battery_capacity_Wh', 50);
        remainingWh = (bp(end)/100) * capacityWh;
        if avgPowerW <= 1e-9
            kpi.batteryProjHours = Inf;
        else
            kpi.batteryProjHours = remainingWh / avgPowerW;
        end
    catch
        kpi.batteryProjHours = NaN;
    end

    try
        if isfield(results,'energyUsedJ'), kpi.energyTotalJ = results.energyUsedJ(end);
        else,                              kpi.energyTotalJ = results.energy(end);
        end
    catch
        kpi.energyTotalJ = NaN;
    end
end

function truth = trueWaterLevel_local(t, scenario, riseRate)
    baseLevel = 0.5;
    switch lower(scenario)
        case 'stable',       truth = baseLevel * ones(size(t));
        case 'receding',     truth = max(baseLevel + 3 + riseRate.*t, 0);
        case 'flash_flood',  truth = baseLevel + 3./(1+exp(-0.25*(t-40)));
        otherwise,           truth = baseLevel + riseRate.*t;
    end
    truth = max(truth, 0);
end

function v = getfield_or_local(s,f,d)
    if isstruct(s) && isfield(s,f), v = s.(f); else, v = d; end
end
