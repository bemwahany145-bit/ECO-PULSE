function proc = signal_processing(tx_signal, rx_signal, params, meta, priorRangeEstimate)

    if nargin < 3, error('signal_processing requires tx, rx, params'); end
    if nargin < 4, meta = []; end
    if nargin < 5, priorRangeEstimate = []; end

    tx_signal = tx_signal(:);
    rx_signal = rx_signal(:);

    if ~isfield(params,'fs'), params.fs = 10e6; end
    PRI  = getfield_or(params,'pulse_repetition_interval',20e-3);
    Np   = getfield_or(params,'num_pulses',20);
    Lp   = max(1, round(params.duty_cycle * PRI * params.fs));
    Ls   = round((PRI - params.duty_cycle*PRI) * params.fs);
    L_pri = Lp + Ls;

    pulse_ref = tx_signal(1:min(Lp, numel(tx_signal)));
    mf        = conj(flipud(pulse_ref));
    mf_output = myConvFFT(rx_signal, mf, 'same');
    corrMag_full = abs(mf_output);

    corrMag_raw = corrMag_full(1:min(L_pri, numel(corrMag_full)));
    win         = local_hann(length(corrMag_raw));
    corrMag     = corrMag_raw .* win;

    rangeMode = getfield_or(params,'range_estimation_mode','ground_truth');
    if strcmpi(rangeMode,'signal_based')
        estimatedRange = estimate_range_signal_based(corrMag, params, priorRangeEstimate);
    elseif ~isempty(meta) && isfield(meta,'delaySamples')
        estimatedRange = meta.delaySamples / params.samplesPerMeter;
    elseif ~isempty(meta) && isfield(meta,'delay_samples')
        estimatedRange = meta.delay_samples / params.samplesPerMeter;
    else
        [~,peakIdx] = max(corrMag);
        estimatedRange = (peakIdx - 1) / params.samplesPerMeter;
    end

    peakVal    = max(corrMag);
    noiseFloor = max(median(corrMag), eps);
    snrEst_dB  = 20 * log10(max(peakVal, eps) / noiseFloor);

    if getfield_or(params,'eigen_snr_enabled',false)
        snrEst_eigen = eigen_snr(rx_signal, L_pri, Np);
        if isfinite(snrEst_eigen)
            snrEst_dB = 0.5*snrEst_dB + 0.5*snrEst_eigen;
        end
    end

    rd_map      = [];
    doppler_axis = [];
    range_axis_rd = [];
    if getfield_or(params,'enable_range_doppler',false) && L_pri > 0
        try
            tot = L_pri * Np;
            if length(rx_signal) >= tot
                slow  = reshape(rx_signal(1:tot), L_pri, Np);
                comp  = zeros(L_pri, Np);
                for m = 1:Np
                    comp(:,m) = myConvFFT(slow(:,m), mf, 'same');
                end
                rd_map = fftshift(fft(comp .* local_hann(Np).', [], 2), 2);
                rd_map = abs(rd_map);
                doppler_axis  = linspace(-0.5, 0.5, Np) * (1/PRI);
                range_axis_rd = (0:L_pri-1) / params.samplesPerMeter;
            end
        catch
            rd_map = [];
        end
    end

    max_range   = params.mountHeight + 5;
    range_bins  = 0 : 1/params.samplesPerMeter : max_range;
    valid_range_axis = (0 : length(corrMag)-1) / params.samplesPerMeter;
    range_profile = interp1(valid_range_axis, corrMag, range_bins, 'linear', 0);

    try, matrix_handler('add', range_profile); catch, end

    cfar_mask_samples = false(size(corrMag));
    cfar_mask         = false(size(range_profile));

    if getfield_or(params,'cfar_enabled',false) && exist('cfar_detector','file')
        try
            min_valid_bin = max(1, round(0.5 * params.samplesPerMeter));
            max_valid_bin = length(corrMag);

            if max_valid_bin > min_valid_bin + ...
                    2*(getfield_or(params,'cfar_train_cells',32)/2 + ...
                       getfield_or(params,'cfar_guard_cells',4)) + 1

                segment = corrMag(min_valid_bin:max_valid_bin);
                seg_mask = cfar_detector(segment, ...
                    getfield_or(params,'cfar_type','CA'), ...
                    getfield_or(params,'cfar_Pfa',1e-6), ...
                    getfield_or(params,'cfar_train_cells',32), ...
                    getfield_or(params,'cfar_guard_cells',4));

                cfar_mask_samples(min_valid_bin:max_valid_bin) = seg_mask(:);

                det_ranges = (find(cfar_mask_samples)-1) / params.samplesPerMeter;
                for r = det_ranges(:)'
                    [~,bi] = min(abs(range_bins - r));
                    cfar_mask(bi) = true;
                end
            end
        catch
            cfar_mask_samples = false(size(corrMag));
            cfar_mask         = false(size(range_profile));
        end
    end

    peakWidth = compute_peak_width(corrMag, params.samplesPerMeter);

    proc = struct();
    proc.range_profile   = range_profile;
    proc.raw_matched     = mf_output;
    proc.range_axis      = range_bins;
    proc.peakVal         = peakVal;
    proc.estimatedRange  = estimatedRange;
    proc.snrEst_dB       = snrEst_dB;
    proc.rd_map          = rd_map;
    proc.doppler_axis    = doppler_axis;
    proc.range_axis_rd   = range_axis_rd;
    proc.cfar_mask       = cfar_mask;
    proc.cfar_mask_raw   = cfar_mask_samples;
    proc.cfarTargets     = sum(cfar_mask_samples);
    proc.peakWidth       = peakWidth;
    proc.sr_range        = NaN;
end

function pw = compute_peak_width(corrMag, spm)
    pw = 0;
    if isempty(corrMag), return; end
    [pv, pi_] = max(corrMag);
    half = pv / sqrt(2);
    left = pi_;
    while left > 1 && corrMag(left) > half, left = left - 1; end
    right = pi_;
    while right < length(corrMag) && corrMag(right) > half, right = right + 1; end
    pw = max((right - left) / spm, 0);
end

function v = getfield_or(s,f,d)
    if isfield(s,f), v = s.(f); else, v = d; end
end

function snr_dB = eigen_snr(rx, L_pri, Np)
    snr_dB = NaN;
    try
        if length(rx) < L_pri*Np, return; end
        X  = reshape(rx(1:L_pri*Np), L_pri, Np);
        R  = (X*X') / Np;
        ev = sort(real(eig(R)), 'descend');
        if numel(ev) < 2, return; end
        noi = median(ev(2:end));
        if noi <= 0, return; end
        snr_dB = 10*log10(ev(1)/noi);
    catch
    end
end

function w = local_hann(L)
    if exist('hann','file') == 2 || exist('hann','builtin')
        try, w = hann(L); return; catch, end
    end
    n = (0:L-1).';
    w = 0.5 - 0.5 * cos(2*pi*n / max(L-1,1));
end

function estimatedRange = estimate_range_signal_based(corrMag, params, priorRangeEstimate)
    noiseFloor = median(corrMag);
    gateWidth_m = getfield_or(params,'track_gate_width_m', 2.0);

    cand = [];
    for i = 2:numel(corrMag)-1
        if corrMag(i) > 3*noiseFloor && corrMag(i) >= corrMag(i-1) && corrMag(i) >= corrMag(i+1)
            cand(end+1) = i;
        end
    end
    [~, gmaxIdx] = max(corrMag);
    if isempty(cand), cand = gmaxIdx; end

    if isempty(priorRangeEstimate) || isnan(priorRangeEstimate)
        estimatedRange = (gmaxIdx - 1) / params.samplesPerMeter;
        return;
    end

    predIdx = round(priorRangeEstimate * params.samplesPerMeter) + 1;
    [~, closestPos] = min(abs(cand - predIdx));
    bestIdx = cand(closestPos);
    if abs(bestIdx - predIdx) / params.samplesPerMeter <= gateWidth_m
        estimatedRange = (bestIdx - 1) / params.samplesPerMeter;
    else
        estimatedRange = (gmaxIdx - 1) / params.samplesPerMeter;
    end
end
