function w = pro_weather_fusion(t, params)
    T = getfield_or(params,'Tsim',120);
    nwp.rain = max(0, getfield_or(params,'rain_rate_mmph',0) * (1+0.4*sin(2*pi*t/T+1)));
    nwp.wind = getfield_or(params,'wind_speed_U10',6) + 1.5*sin(2*pi*t/90);
    nwp.conf = 0.75;
    loc.rain = nwp.rain + 0.1*randn;
    loc.wind = nwp.wind + 0.3*randn;
    loc.conf = 0.95;
    wn = nwp.conf; wl = loc.conf;
    w.rain_rate_mmph = (wn*nwp.rain + wl*loc.rain) / (wn+wl);
    w.wind_speed_U10 = (wn*nwp.wind + wl*loc.wind) / (wn+wl);
    w.confidence     = 0.5*(wn+wl);
    w.humidity_pct   = 60 + 20*(w.rain_rate_mmph > 0);
end
function v = getfield_or(s,f,d), if isfield(s,f), v=s.(f); else, v=d; end; end
