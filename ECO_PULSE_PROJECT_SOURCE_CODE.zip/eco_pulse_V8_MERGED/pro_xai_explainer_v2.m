function exp = pro_xai_explainer_v2(features, decision, lstm_attention)

    if nargin < 3, lstm_attention = []; end

    names = {'SNR','level','vz','cfar','peakW','rate','waterDoppler'};

    snr_val   = getf_(features, 'snr',         15);
    level_val = getf_(features, 'waterLevel',   0.5);
    vz_val    = abs(getf_(features, 'surfaceVz', 0));
    cfar_val  = getf_(features, 'cfarTargets',  0);
    peak_val  = getf_(features, 'peakWidth',    0);
    rate_val  = getf_(features, 'rateOfRise',   0);
    wdr_val   = getf_(features, 'waterDopplerRatio', 1);
    fcst_val  = getf_(decision,  'forecastLevel', level_val);

    vals = [snr_val, level_val, vz_val, cfar_val, peak_val, rate_val, wdr_val];

    base      = [15, 0.5, 0.05, 0, 0.12, 0.0, 1.0];
    norm_base = max(abs(base), [1, 0.5, 0.01, 1, 0.05, 0.005, 0.5]);

    w_rule = [0.12, 0.30, 0.05, 0.08, 0.08, 0.22, 0.15];

    if ~isempty(lstm_attention) && numel(lstm_attention) == 3
        a_level = lstm_attention(1);
        a_rate  = lstm_attention(2) + lstm_attention(3);
        a_sum   = a_level + a_rate + eps;
        budget  = w_rule(2) + w_rule(6);
        w = w_rule;
        w(2) = budget * (a_level / a_sum);
        w(6) = budget * (a_rate  / a_sum);
    else
        w = w_rule;
    end

    delta   = vals - base;
    contrib = w .* (delta ./ norm_base);
    contrib = max(min(contrib, 1), -1);

    [~, idx] = sort(abs(contrib), 'descend');

    exp.names         = names;
    exp.values        = vals;
    exp.contrib       = contrib;
    exp.ranked        = idx;
    exp.top1          = names{idx(1)};
    exp.top1_contrib  = contrib(idx(1));
    exp.forecastLevel = fcst_val;
    exp.weights       = w;
    exp.dynamic       = ~isempty(lstm_attention);
end

function v = getf_(s, f, def)
    if isstruct(s) && isfield(s, f), v = s.(f); else, v = def; end
end
