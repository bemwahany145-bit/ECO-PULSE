function ledger = pro_blockchain_ledger(ledger, event, features)
    if isempty(ledger), ledger = {}; end
    prev = '0';
    if ~isempty(ledger), prev = ledger{end}.hash; end
    b = struct();
    b.index     = numel(ledger) + 1;
    b.timestamp = event.timestamp;
    b.status    = event.status;
    b.level     = features.waterLevel;
    b.rate      = features.rateOfRise;
    b.prev_hash = prev;
    pay = sprintf('%d|%.3f|%s|%.4f|%.6f|%s', ...
        b.index, b.timestamp, b.status, b.level, b.rate, b.prev_hash);
    b.hash = fnv_hash(pay);
    ledger{end+1} = b;
end
function h = fnv_hash(s)
    H = uint32(2166136261);
    for i = 1:numel(s)
        H = bitxor(H, uint32(double(s(i))));
        H = uint32(mod(double(H) * 16777619, 2^32));
    end
    h = sprintf('%08x', H);
end
