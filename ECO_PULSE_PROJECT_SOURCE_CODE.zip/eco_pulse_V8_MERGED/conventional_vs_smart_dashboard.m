function conventional_vs_smart_dashboard(scenarioIn)

    if nargin<1 || isempty(scenarioIn), scenarioIn = 'fast_rise'; end

    COL_BG      = [0.98 0.98 0.99];
    COL_PANEL   = [1 1 1];
    COL_TEXT    = [0.10 0.12 0.16];
    COL_MUTED   = [0.45 0.48 0.55];
    COL_SMART   = [0.11 0.55 0.35];
    COL_CONV    = [0.75 0.30 0.20];
    COL_ACCENT  = [0.10 0.30 0.65];

    fig = uifigure('Name','Conventional Radar vs Smart Radar — Executive Comparison', ...
        'Position',[80 60 1300 830],'Color',COL_BG);

    uilabel(fig,'Position',[30 780 900 32],'Text','Conventional Radar vs. Our Smart Radar', ...
        'FontSize',22,'FontWeight','bold','FontColor',COL_TEXT);
    uilabel(fig,'Position',[30 755 900 22], ...
        'Text','Same synthetic ground truth and noise realization for both systems — every number below is measured, not illustrative.', ...
        'FontSize',12,'FontColor',COL_MUTED);

    uilabel(fig,'Position',[900 782 90 22],'Text','Scenario:','FontSize',12,'FontColor',COL_TEXT);
    ddScenario = uidropdown(fig,'Position',[985 780 280 26], ...
        'Items',{'stable','slow_rise','fast_rise','receding','flash_flood'}, 'Value',scenarioIn, ...
        'FontSize',12);

    cardY = 690; cardW = 300; cardH = 80; gap = 20;
    pnlRMSE = uipanel(fig,'Position',[30 cardY cardW cardH],'BackgroundColor',COL_PANEL,'BorderColor',[0.85 0.86 0.9]);
    lbRMSE_title = uilabel(pnlRMSE,'Position',[15 48 270 22],'Text','RANGE/LEVEL ACCURACY (RMSE)','FontSize',11,'FontColor',COL_MUTED,'FontWeight','bold');
    lbRMSE_val   = uilabel(pnlRMSE,'Position',[15 8 270 34],'Text','—','FontSize',20,'FontWeight','bold','FontColor',COL_TEXT);

    pnlFlips = uipanel(fig,'Position',[30+cardW+gap cardY cardW cardH],'BackgroundColor',COL_PANEL,'BorderColor',[0.85 0.86 0.9]);
    lbFlips_title = uilabel(pnlFlips,'Position',[15 48 270 22],'Text','FALSE-ALARM FLIPS','FontSize',11,'FontColor',COL_MUTED,'FontWeight','bold');
    lbFlips_val   = uilabel(pnlFlips,'Position',[15 8 270 34],'Text','—','FontSize',20,'FontWeight','bold','FontColor',COL_TEXT);

    pnlLat = uipanel(fig,'Position',[30+2*(cardW+gap) cardY cardW cardH],'BackgroundColor',COL_PANEL,'BorderColor',[0.85 0.86 0.9]);
    lbLat_title = uilabel(pnlLat,'Position',[15 48 270 22],'Text','ALARM LATENCY vs TRUE CROSSING','FontSize',11,'FontColor',COL_MUTED,'FontWeight','bold');
    lbLat_val   = uilabel(pnlLat,'Position',[15 8 270 34],'Text','—','FontSize',20,'FontWeight','bold','FontColor',COL_TEXT);

    pnlStatus = uipanel(fig,'Position',[30+3*(cardW+gap) cardY cardW cardH],'BackgroundColor',COL_PANEL,'BorderColor',[0.85 0.86 0.9]);
    lbStatus_title = uilabel(pnlStatus,'Position',[15 48 270 22],'Text','FINAL STATUS','FontSize',11,'FontColor',COL_MUTED,'FontWeight','bold');
    lbStatus_val   = uilabel(pnlStatus,'Position',[15 8 270 34],'Text','—','FontSize',16,'FontWeight','bold','FontColor',COL_TEXT);

    axLevel = uiaxes(fig,'Position',[30 340 620 320],'Box','on');
    axLevel.Color = COL_PANEL; axLevel.XColor = COL_MUTED; axLevel.YColor = COL_MUTED;
    title(axLevel,'Level Tracking: Ground Truth vs Both Systems','Color',COL_TEXT,'FontWeight','bold');
    xlabel(axLevel,'Time (s)'); ylabel(axLevel,'Water level (m)'); grid(axLevel,'on');

    axState = uiaxes(fig,'Position',[670 340 600 320],'Box','on');
    axState.Color = COL_PANEL; axState.XColor = COL_MUTED; axState.YColor = COL_MUTED;
    title(axState,'Alarm State Timeline','Color',COL_TEXT,'FontWeight','bold');
    xlabel(axState,'Time (s)'); ylabel(axState,'0=Monitor 1=Alert 2=Flood'); grid(axState,'on');

    pnlNarr = uipanel(fig,'Position',[30 30 1240 290],'Title','What This Means', ...
        'BackgroundColor',COL_PANEL,'FontWeight','bold','ForegroundColor',COL_TEXT,'BorderColor',[0.85 0.86 0.9]);
    lbNarr = uilabel(pnlNarr,'Position',[15 15 1210 240],'Text','Loading…','FontSize',13, ...
        'FontColor',COL_TEXT,'VerticalAlignment','top','WordWrap','on');

    cache = struct();

    function loadAndRender(scen)
        try
            if ~isfield(cache, scen)
                cache.(scen) = compare_conventional_vs_smart(scen, false);
            end
            r = cache.(scen);
            if ~r.ok
                lbNarr.Text = sprintf('Comparison failed for %s: %s', scen, r.error);
                return;
            end

            lbRMSE_val.Text = sprintf('%.3f m  vs  %.3f m', r.conventional.rmse_m, r.smart.rmse_m);
            if r.smart.rmse_m <= r.conventional.rmse_m
                lbRMSE_val.FontColor = COL_SMART;
            else
                lbRMSE_val.FontColor = COL_CONV;
            end

            lbFlips_val.Text = sprintf('%d  vs  %d', r.conventional.falseAlarmFlips, r.smart.falseAlarmFlips);
            lbFlips_val.FontColor = COL_ACCENT;

            lbLat_val.Text = sprintf('%.1fs  vs  %.1fs', r.conventional.alarmLatencyS, r.smart.alarmLatencyS);
            lbLat_val.FontColor = COL_ACCENT;

            lbStatus_val.Text = sprintf('%s  vs  %s', r.conventional.finalStatus, r.smart.finalStatus);
            lbStatus_val.FontColor = COL_TEXT;

            cla(axLevel);
            plot(axLevel, r.time, r.truth, '-', 'Color',[0.2 0.2 0.2], 'LineWidth', 1.8); hold(axLevel,'on');
            plot(axLevel, r.rConv.time, r.rConv.levelRaw, ':', 'Color',COL_CONV, 'LineWidth', 1.4);
            plot(axLevel, r.rSmart.time, r.rSmart.waterLevelKalman, '-', 'Color',COL_SMART, 'LineWidth', 1.8);
            legend(axLevel, {'Ground truth','Conventional (raw)','Smart (Kalman)'}, 'Location','northwest');

            cla(axState);
            plot(axState, r.rConv.time, r.rConv.state, '-', 'Color',COL_CONV, 'LineWidth', 1.8); hold(axState,'on');
            plot(axState, r.rSmart.time, r.rSmart.state, '-', 'Color',COL_SMART, 'LineWidth', 1.8);
            legend(axState, {'Conventional','Smart (ours)'}, 'Location','northwest');
            ylim(axState, [-0.2 2.2]);

            rmseVerdict = 'more accurate';
            if r.smart.rmse_m > r.conventional.rmse_m
                rmseVerdict = 'LESS accurate (Kalman lag on a fast, non-linear rise)';
            end
            lbNarr.Text = sprintf([ ...
                'Scenario: %s\n\n' ...
                '• Accuracy: the smart system is %s (RMSE %.3f m vs %.3f m). ' ...
                'A Kalman filter trades noise-robustness for a small amount of lag during very fast transitions, ' ...
                'which is the honest reason smart accuracy can be worse specifically during flash_flood.\n\n' ...
                '• False-alarm behaviour: the conventional system flipped state %d time(s) (noise-driven chatter, no debounce). ' ...
                'The smart system flipped %d time(s), because its multi-tick persistence/validation window filters out momentary noise.\n\n' ...
                '• Status memory: the smart system does not immediately clear an active alert just because the level dipped ' ...
                'slightly - it requires sustained confirmation, avoiding a dangerous premature "all clear". The conventional ' ...
                'system has no memory of this kind: it reports whatever the instantaneous noisy reading says right now.\n\n' ...
                '• Alarm timing: conventional=%.1fs, smart=%.1fs relative to the TRUE physical threshold crossing ' ...
                '(negative = fired before the crossing, via forecast-driven early warning).'], ...
                scen, rmseVerdict, r.conventional.rmse_m, r.smart.rmse_m, ...
                r.conventional.falseAlarmFlips, r.smart.falseAlarmFlips, ...
                r.conventional.alarmLatencyS, r.smart.alarmLatencyS);

            cache.(scen) = r;
        catch e
            lbNarr.Text = sprintf('Error rendering %s: %s', scen, e.message);
        end
    end

    ddScenario.ValueChangedFcn = @(dd,ev) loadAndRender(dd.Value);
    loadAndRender(scenarioIn);
end
