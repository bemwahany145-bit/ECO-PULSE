function [mode, duty] = adaptive_mode_select(riskScore, batteryPct, solarW, params)

    calm_duty = getfield_or(params,'energy_calm_duty', 0.6);
    low_pct   = getfield_or(params,'energy_low_battery_pct', 20);
    low_duty  = getfield_or(params,'energy_low_battery_duty', 0.5);
    risk_thr  = getfield_or(params,'energy_risk_threshold', 0.6);
    vb        = isfield(params,'verbose') && params.verbose;

    base_duty = calm_duty;
    if batteryPct < low_pct
        base_duty = base_duty * low_duty;
        if vb, fprintf('[EnergyMgr] Low battery %.0f%% -> duty=%.0f%%\n', batteryPct, base_duty*100); end
    end

    if riskScore >= risk_thr
        mode = 2;
        duty = 1.0;
        if vb, fprintf('[EnergyMgr] Mode2 CHIRP | Solar=%.1fW | Battery=%.0f%%\n', solarW, batteryPct); end
    else
        mode = 1;
        duty = base_duty;
    end
end

function v = getfield_or(s,f,d)
    if isstruct(s) && isfield(s,f), v = s.(f); else, v = d; end
end
