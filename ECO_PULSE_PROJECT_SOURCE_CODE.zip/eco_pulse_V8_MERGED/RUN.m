
clc; close all;
fprintf('\n========================================\n');
fprintf(' ⚡  Radar v4 — Launcher\n');
fprintf('========================================\n\n');

addpath(fileparts(mfilename('fullpath')));

v = version('-release');
fprintf('MATLAB Release : %s\n', v);

if exist('uifigure','file') ~= 2
    fprintf('\n[!] Your MATLAB does not support uifigure.\n');
    fprintf('    Falling back to the classic dashboard.\n\n');
    params = get_params('slow_rise');
    results = main_flood_monitoring_system_core(params);
    dashboard_philip(results, params);
else
    fprintf('uifigure support : OK\n');
    fprintf('Launching Ultimate GUI...\n\n');
    flood_gui_ultimate();
end
