function result = test_track_before_detect(params, nTicks)

    if nargin<1 || isempty(params), params = 'fast_rise'; end
    if ischar(params), params = get_params(params); end
    if nargin<2, nTicks = 60; end

    dt = getfield_or_local(params,'dt',1);
    gateWidth_m = getfield_or_local(params,'track_gate_width_m', 2.0);

    errNaive = nan(nTicks,1); errGated = nan(nTicks,1);
    stateNaive = []; stateGated = [];
    gateLostCount = 0;

    fprintf('\n--- Track-Before-Detect Test (%s, %d ticks, gate=%.1fm) ---\n', params.scenario, nTicks, gateWidth_m);
    for k = 1:nTicks
        t = (k-1)*dt;
        try
            [tx, ~, ~] = signal_generation(1, params);
            [rx, meta] = environment_model(tx, params, t);
            trueRange = meta.range;

            mf = conj(flipud(tx));
            mfAbs = abs(myConvFFT(rx, mf, 'same'));
            noiseFloor = median(mfAbs);

            cand = [];
            for i = 2:numel(mfAbs)-1
                if mfAbs(i) > 3*noiseFloor && mfAbs(i) >= mfAbs(i-1) && mfAbs(i) >= mfAbs(i+1)
                    cand(end+1) = i;
                end
            end
            if isempty(cand), [~, gmax] = max(mfAbs); cand = gmax; end

            [~, idxNaive] = max(mfAbs);
            rangeNaive = (idxNaive-1) / params.samplesPerMeter;
            levelMeasNaive = params.mountHeight - rangeNaive;
            [xEstNaive, stateNaive] = kalman_tracker(levelMeasNaive, dt, stateNaive);
            errNaive(k) = abs(rangeNaive - trueRange);

            if isempty(stateGated)
                idxGated = idxNaive;
            else
                predictedLevel = stateGated.x(1) + stateGated.x(2)*dt;
                predictedRange = params.mountHeight - predictedLevel;
                predIdx = round(predictedRange * params.samplesPerMeter) + 1;
                [~, closestPos] = min(abs(cand - predIdx));
                bestIdx = cand(closestPos);
                if abs(bestIdx - predIdx) / params.samplesPerMeter <= gateWidth_m
                    idxGated = bestIdx;
                else
                    gateLostCount = gateLostCount + 1;
                    idxGated = idxNaive;
                end
            end
            rangeGated = (idxGated-1) / params.samplesPerMeter;
            levelMeasGated = params.mountHeight - rangeGated;
            [xEstGated, stateGated] = kalman_tracker(levelMeasGated, dt, stateGated);
            errGated(k) = abs(rangeGated - trueRange);

        catch e
            fprintf('  tick %d FAILED: %s\n', k, e.message);
        end
    end

    result.ok = true;
    result.rmse_naive_m = sqrt(mean(errNaive(~isnan(errNaive)).^2));
    result.rmse_gated_m = sqrt(mean(errGated(~isnan(errGated)).^2));
    result.improvementPct = 100*(result.rmse_naive_m - result.rmse_gated_m)/max(result.rmse_naive_m,eps);
    result.gateLostCount = gateLostCount;
    result.nTicks = nTicks;

    fprintf('  Naive global-max (current pipeline) RMSE : %.3f m\n', result.rmse_naive_m);
    fprintf('  Gated track-before-detect RMSE           : %.3f m\n', result.rmse_gated_m);
    fprintf('  Improvement                                : %+.1f %%\n', result.improvementPct);
    fprintf('  Gate fell back to naive on %d/%d ticks (no plausible candidate within %.1fm of prediction)\n', ...
        gateLostCount, nTicks, gateWidth_m);
end

function v = getfield_or_local(s,f,d)
    if isstruct(s) && isfield(s,f), v = s.(f); else, v = d; end
end
