function result = compare_range_estimators(params, nTrials)

    if nargin<1, params = get_params('fast_rise'); end
    if nargin<2, nTrials = 15; end

    errMF = zeros(nTrials,1); errMUSIC = zeros(nTrials,1); errESPRIT = zeros(nTrials,1);
    okCount = 0;

    fprintf('\n--- Range Estimator Comparison (matched-filter vs MUSIC vs ESPRIT), n=%d trials ---\n', nTrials);
    for i = 1:nTrials
        try
            rng(9000+i);
            p = params;
            [tx, ~, ~] = signal_generation(1, p);
            [rx, meta] = environment_model(tx, p, 0);
            trueRange = meta.range;

            mf = conj(flipud(tx));
            mfAbs = abs(myConvFFT(rx, mf, 'same'));
            [~, peakIdx] = max(mfAbs);
            rangeMF = (peakIdx-1) / p.samplesPerMeter;

            rangeMUSIC  = music_esprit(rx, p, 'music', 1);
            rangeESPRIT = music_esprit(rx, p, 'esprit', 1);

            errMF(i)     = abs(rangeMF     - trueRange);
            errMUSIC(i)  = abs(rangeMUSIC  - trueRange);
            errESPRIT(i) = abs(rangeESPRIT - trueRange);
            okCount = okCount + 1;
        catch e
            errMF(i) = NaN; errMUSIC(i) = NaN; errESPRIT(i) = NaN;
            fprintf('  trial %d FAILED: %s\n', i, e.message);
        end
    end

    result.ok = okCount > 0;
    result.n  = okCount;
    result.rmse_MF_m     = sqrt(nanmean_local(errMF.^2));
    result.rmse_MUSIC_m  = sqrt(nanmean_local(errMUSIC.^2));
    result.rmse_ESPRIT_m = sqrt(nanmean_local(errESPRIT.^2));

    fprintf('  Matched filter (current pipeline) RMSE : %.4f m\n', result.rmse_MF_m);
    fprintf('  MUSIC  RMSE                             : %.4f m\n', result.rmse_MUSIC_m);
    fprintf('  ESPRIT RMSE                              : %.4f m\n', result.rmse_ESPRIT_m);

    [bestVal, bestIdx] = min([result.rmse_MF_m, result.rmse_MUSIC_m, result.rmse_ESPRIT_m]);
    names = {'Matched filter','MUSIC','ESPRIT'};
    fprintf('  Best on this waveform/SNR: %s (RMSE=%.4f m)\n', names{bestIdx}, bestVal);
    fprintf('  Note: MUSIC/ESPRIT typically only outperform a matched filter when\n');
    fprintf('  multiple closely-spaced targets are present or SNR is very low with a\n');
    fprintf('  long observation window - for a single dominant target at moderate SNR\n');
    fprintf('  (this scenario), a plain matched filter can legitimately be competitive.\n');
end

function m = nanmean_local(x)
    x = x(~isnan(x));
    if isempty(x), m = NaN; else, m = mean(x); end
end
