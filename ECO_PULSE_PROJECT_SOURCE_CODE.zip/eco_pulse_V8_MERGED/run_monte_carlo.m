function mc = run_monte_carlo(paramsBase, nRuns, doRoc)

    if nargin<2, nRuns = 20; end
    if nargin<1, paramsBase = get_params(); end
    if nargin<3, doRoc = true; end

    Pd_list  = false(nRuns,1);
    Pfa_list = false(nRuns,1);

    for i = 1:nRuns
        rng(paramsBase.mc_seed_base + i);
        p = paramsBase; p.mc_runs = 0;
        if mod(i,2)==0
            p = set_scenario(p, 'fast_rise');
            truth = 1;
        else
            p = set_scenario(p, 'stable');
            truth = 0;
        end
        res = main_flood_monitoring_system_core(p);

        alarm = ~strcmp(res.finalStatus,'monitoring');
        if truth==1, Pd_list(i)  = alarm;
        else,        Pfa_list(i) = alarm;
        end
        fprintf('[MC] run %d/%d  scenario=%s (rise_rate=%.3f)  final=%s  alarm=%d\n', ...
                i, nRuns, p.scenario, p.rise_rate, res.finalStatus, alarm);
    end

    mc.nRuns = nRuns;
    mc.Pd    = mean(Pd_list(2:2:end));
    mc.Pfa   = mean(Pfa_list(1:2:end));

    if ~doRoc
        fprintf('[MC] Summary: Pd=%.2f Pfa=%.2f (ROC sweep skipped)\n', mc.Pd, mc.Pfa);
        return;
    end

    wins = [10 30 60 90 120];
    mc.roc.Pd = zeros(size(wins));
    mc.roc.Pfa = zeros(size(wins));
    for w=1:length(wins)
        p = paramsBase; p.mc_runs = 0; p.persistenceWindow = wins(w);
        pd = 0; pfa = 0;
        for i=1:4
            rng(paramsBase.mc_seed_base + 1000 + i);
            p = set_scenario(p, 'fast_rise');
            res = main_flood_monitoring_system_core(p);
            pd = pd + ~strcmp(res.finalStatus,'monitoring');
            p = set_scenario(p, 'stable');
            res = main_flood_monitoring_system_core(p);
            pfa = pfa + ~strcmp(res.finalStatus,'monitoring');
        end
        mc.roc.Pd(w)  = pd/4;
        mc.roc.Pfa(w) = pfa/4;
    end

    fprintf('[MC] Summary: Pd=%.2f Pfa=%.2f\n', mc.Pd, mc.Pfa);
end

function p = set_scenario(p, name)
    p.scenario = name;
    switch lower(name)
        case 'stable',      p.rise_rate = 0.0;
        case 'slow_rise',   p.rise_rate = 0.025;
        case 'fast_rise',   p.rise_rate = 0.08;
        case 'receding',    p.rise_rate = -0.015;
        case 'flash_flood', p.rise_rate = 0.15;
        otherwise,          p.rise_rate = 0.025;
    end
end
