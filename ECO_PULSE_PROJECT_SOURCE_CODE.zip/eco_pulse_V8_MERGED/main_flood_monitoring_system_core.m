function results = main_flood_monitoring_system_core(params)

    if nargin<1, params = get_params(); end

    if params.Tsim < params.persistenceWindow+5
        params.Tsim = params.persistenceWindow + 60;
    end

    matrix_handler('init', params);

    history = struct();
    history.validationActive  = false;
    history.validationStart   = 0;
    history.consecutiveCount  = 0;
    history.pendingStatus     = 'monitoring';
    history.confirmedStatus   = 'monitoring';
    history.lastConfirmedTime = 0;
    history.levelBuffer       = [];
    history.rateBuffer        = [];

    prevLevel     = [];
    kalmanState   = [];
    cum_energy    = 0;
    battery_pct   = 100;
    battState     = [];
    timeVec       = 0:params.dt:params.Tsim;
    N             = length(timeVec);

    waterHistory      = zeros(1,N);
    waterKalman       = zeros(1,N);
    stateHistory      = zeros(1,N);
    snrHistory        = zeros(1,N);
    rangeHistory      = zeros(1,N);
    rateHistory       = zeros(1,N);
    forecastHistory   = zeros(1,N);
    riskHistory       = zeros(1,N);
    timeRemHistory    = zeros(1,N);
    energyHistory     = zeros(1,N);
    batteryHistory    = zeros(1,N);
    waterDopplerHist  = zeros(1,N);
    xaiTop1Hist       = cell(1,N);
    lastRangeProfile  = [];
    lastRdMap         = [];
    cfarMaskHist      = [];
    waveDirs          = [];

    for k = 1:N
        t = timeVec(k);

        w = weather_model(t, params);
        params.wind_speed_U10 = w.U10;
        params.rain_rate_mmph = w.rain;

        if strcmp(history.confirmedStatus,'monitoring'), mode = 1; else, mode = 2; end

        [tx_signal,~,~] = signal_generation(mode, params);

        [rx_signal, meta] = environment_model(tx_signal, params, t);

        if ~isempty(kalmanState)
            predictedLevel = kalmanState.x(1) + kalmanState.x(2)*params.dt;
            priorRangeEstimate = params.mountHeight - predictedLevel;
        else
            priorRangeEstimate = [];
        end
        proc = signal_processing(tx_signal, rx_signal, params, meta, priorRangeEstimate);

        features = feature_extraction(proc, prevLevel, params, meta, kalmanState);
        kalmanState = features.kalmanState;
        features.timestamp = t;

        decision = decision_logic(features, params, history);

        vd = alarm_validation(decision, history, params);
        history = vd.history;

        waterHistory(k)    = features.waterLevel;
        waterKalman(k)     = features.waterLevel;
        snrHistory(k)      = features.snr;
        rangeHistory(k)    = features.range;
        rateHistory(k)     = features.rateOfRise;
        forecastHistory(k) = decision.forecastLevel;
        riskHistory(k)     = decision.riskProb;
        timeRemHistory(k)  = vd.timeRemaining;
        waterDopplerHist(k)= getfield_or_core(features,'waterDopplerRatio',NaN);

        if getfield_or_core(params,'energy_adaptive_enabled',true)
            [~, duty_em] = adaptive_mode_select(decision.riskProb, battery_pct, 0, params);
        else
            duty_em = 1.0;
        end
        P_W = (mode==1) * params.energy.P_zc + (mode==2) * params.energy.P_chirp;
        duty_tick = params.duty_cycle * duty_em;
        dE = P_W * duty_tick * params.dt;
        cum_energy = cum_energy + dE;
        [sol, battState] = pro_solar_manager(t, dE, params, battState);
        battery_pct = sol.battery_pct;
        energyHistory(k)  = cum_energy;
        batteryHistory(k) = battery_pct;

        try
            attn = getfield_or_core(decision,'lstmAttention',[]);
            xexp = pro_xai_explainer_v2(features, decision, attn);
            xaiTop1Hist{k} = xexp.top1;
        catch
            xaiTop1Hist{k} = '';
        end

        switch vd.confirmedStatus
            case 'monitoring', stateHistory(k)=0;
            case 'alert',      stateHistory(k)=1;
            otherwise,         stateHistory(k)=2;
        end

        prevLevel = features.waterLevel;
        lastRangeProfile = proc.range_profile;
        if isfield(proc,'rd_map') && ~isempty(proc.rd_map), lastRdMap = proc.rd_map; end
        if isfield(proc,'cfar_mask')
            cfarMaskHist = [cfarMaskHist; double(proc.cfar_mask)];
        end
        waveDirs = [waveDirs; 2*pi*rand];
    end

    [filteredMatrix, rawMatrix] = matrix_handler('get_all');

    results = struct();
    results.time              = timeVec;
    results.waterLevel        = waterHistory;
    results.waterLevelKalman  = waterKalman;
    results.rateOfRise        = rateHistory;
    results.state             = stateHistory;
    results.snr               = snrHistory;
    results.range             = rangeHistory;
    results.rangeProfile      = lastRangeProfile;
    results.rdMap             = lastRdMap;
    results.cfarMaskHist      = cfarMaskHist;
    results.matrixData        = filteredMatrix;
    results.rawMatrix         = rawMatrix;
    results.forecastLevel     = forecastHistory;
    results.riskProb          = riskHistory;
    results.timeRemaining     = timeRemHistory;
    results.waveDirs          = waveDirs;
    results.finalStatus       = history.confirmedStatus;
    results.energyUsedJ       = energyHistory;
    results.batteryPct        = batteryHistory;
    results.waterDopplerRatio = waterDopplerHist;
    results.xaiTop1           = xaiTop1Hist;
    if strcmp(history.confirmedStatus,'monitoring'), results.finalMode = 1;
    else, results.finalMode = 2; end
end

function v = getfield_or_core(s,f,d)
    if isstruct(s) && isfield(s,f), v = s.(f); else, v = d; end
end
