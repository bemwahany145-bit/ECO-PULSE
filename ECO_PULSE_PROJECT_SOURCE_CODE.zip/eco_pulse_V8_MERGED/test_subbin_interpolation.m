function result = test_subbin_interpolation(params, nTrials)

    if nargin<1, params = get_params('fast_rise'); end
    if nargin<2, nTrials = 20; end

    errRaw = zeros(nTrials,1); errInterp = zeros(nTrials,1);
    fprintf('\n--- Sub-bin Peak Interpolation Test, n=%d trials ---\n', nTrials);
    for i = 1:nTrials
        try
            rng(11000+i);
            p = params;
            [tx, ~, ~] = signal_generation(1, p);
            [rx, meta] = environment_model(tx, p, 0);
            trueRange = meta.range;

            mf = conj(flipud(tx));
            mfAbs = abs(myConvFFT(rx, mf, 'same'));
            [pk, peakIdx] = max(mfAbs);
            rangeRaw = (peakIdx-1) / p.samplesPerMeter;

            if peakIdx > 1 && peakIdx < numel(mfAbs)
                y1 = mfAbs(peakIdx-1); y2 = mfAbs(peakIdx); y3 = mfAbs(peakIdx+1);
                denom = (y1 - 2*y2 + y3);
                if abs(denom) > eps
                    delta = 0.5*(y1 - y3)/denom;
                else
                    delta = 0;
                end
            else
                delta = 0;
            end
            rangeInterp = (peakIdx - 1 + delta) / p.samplesPerMeter;

            errRaw(i)    = abs(rangeRaw    - trueRange);
            errInterp(i) = abs(rangeInterp - trueRange);
        catch e
            errRaw(i) = NaN; errInterp(i) = NaN;
            fprintf('  trial %d FAILED: %s\n', i, e.message);
        end
    end

    result.ok = true;
    result.rmse_raw_m    = sqrt(mean(errRaw(~isnan(errRaw)).^2));
    result.rmse_interp_m = sqrt(mean(errInterp(~isnan(errInterp)).^2));
    result.improvementPct = 100*(result.rmse_raw_m - result.rmse_interp_m)/max(result.rmse_raw_m,eps);

    fprintf('  Raw integer-bin peak RMSE      : %.4f m  (quantization step = %.4f m)\n', ...
        result.rmse_raw_m, 1/params.samplesPerMeter);
    fprintf('  Parabolic sub-bin interp RMSE  : %.4f m\n', result.rmse_interp_m);
    fprintf('  Improvement                     : %+.1f %%\n', result.improvementPct);
end
