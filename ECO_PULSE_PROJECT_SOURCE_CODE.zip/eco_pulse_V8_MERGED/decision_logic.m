function decision = decision_logic(features, params, history)

    if nargin < 3, history = struct(); end

    decision.mode           = 1;
    decision.status         = 'monitoring';
    decision.levelFlag      = false;
    decision.rateFlag       = false;
    decision.snrValid       = false;
    decision.changeDetected = false;
    decision.timestamp      = features.timestamp;
    decision.waterLevel     = features.waterLevel;
    decision.rateOfRise     = features.rateOfRise;
    decision.snr            = features.snr;
    decision.forecastLevel  = NaN;
    decision.riskProb       = 0;
    decision.mlLabel        = "";
    decision.forecastFlag   = false;
    decision.lstmAttention  = [];

    if features.snr >= params.snrThreshold
        decision.snrValid = true;
    else
        if isfield(params,'verbose') && params.verbose
            fprintf('[decision_logic] t=%5.1fs | SNR=%.1fdB < %.1f -> ignored\n', ...
                features.timestamp, features.snr, params.snrThreshold);
        end
        return;
    end

    if features.waterLevel >= params.levelFlood
        decision.levelFlag = true; decision.status='flood_risk'; decision.mode=2;
    elseif features.waterLevel >= params.levelAlert
        decision.levelFlag = true; decision.status='alert';      decision.mode=2;
    end
    if features.rateOfRise >= params.rateFlood
        decision.rateFlag = true;
        if ~strcmp(decision.status,'flood_risk')
            decision.status='flood_risk'; decision.mode=2;
        end
    elseif features.rateOfRise >= params.rateAlert
        decision.rateFlag = true;
        if strcmp(decision.status,'monitoring')
            decision.status='alert'; decision.mode=2;
        end
    end
    if decision.levelFlag || decision.rateFlag
        decision.changeDetected = true;
    end

    rain_mmph = getfield_or(params,'rain_rate_mmph',0);
    if getfield_or(params,'rain_forecast_enabled',true)
        rain_contribution = rain_mmph * getfield_or(params,'rain_to_rise_coeff',0.001);
    else
        rain_contribution = 0;
    end
    horizon = getfield_or(params,'forecast_horizon_s',30);
    rain_delta = rain_contribution * horizon;

    forecaster_type = lower(getfield_or(params,'forecaster_type','arima'));

    if strcmp(forecaster_type,'lstm') && isfield(history,'levelBuffer') && ...
            numel(history.levelBuffer) >= 10 && exist('pro_lstm_forecaster_v2','file')
        try
            rateBuf = getfield_or(history,'rateBuffer', features.rateOfRise);
            [pred, decision.lstmAttention] = pro_lstm_forecaster_v2( ...
                history.levelBuffer, rateBuf, rain_mmph, horizon, params);
            decision.forecastLevel = pred;
            decision.riskProb = smooth_risk(pred, params.levelAlert, params.levelFlood);
        catch
            pred = features.waterLevel + features.rateOfRise * horizon + rain_delta;
            decision.forecastLevel = pred;
            decision.riskProb = smooth_risk(pred, params.levelAlert, params.levelFlood);
        end
    elseif getfield_or(params,'forecast_enabled',false) && exist('arima_predictor','file')
        try
            [pred, pStd] = arima_predictor(history, features, params);
            pred = pred + rain_delta;
            decision.forecastLevel = pred;
            if pStd > 0
                z = (params.levelFlood - pred) / pStd;
                decision.riskProb = 1 - 0.5*erfc(-z/sqrt(2));
            else
                decision.riskProb = smooth_risk(pred, params.levelAlert, params.levelFlood);
            end
        catch
            pred = features.waterLevel + features.rateOfRise * horizon + rain_delta;
            decision.forecastLevel = pred;
            decision.riskProb = smooth_risk(pred, params.levelAlert, params.levelFlood);
        end
    else
        pred = features.waterLevel + features.rateOfRise * horizon + rain_delta;
        decision.forecastLevel = pred;
        decision.riskProb = smooth_risk(pred, params.levelAlert, params.levelFlood);
    end

    if getfield_or(params,'forecast_early_warning',true) && isfinite(decision.forecastLevel)
        if decision.forecastLevel >= params.levelFlood && ~strcmp(decision.status,'flood_risk')
            decision.status = 'flood_risk'; decision.mode = 2;
            decision.changeDetected = true; decision.forecastFlag = true;
        elseif decision.forecastLevel >= params.levelAlert && strcmp(decision.status,'monitoring')
            decision.status = 'alert'; decision.mode = 2;
            decision.changeDetected = true; decision.forecastFlag = true;
        end
    end

    if getfield_or(params,'ml_classifier_enabled',false) && exist('ml_classifier','file')
        try
            decision.mlLabel = ml_classifier(features, params);
            if strcmpi(decision.mlLabel,'flood_risk') && strcmp(decision.status,'monitoring')
                decision.status = 'alert';
                decision.changeDetected = true;
                decision.mode = 2;
            end
        catch
        end
    end

    if isfield(params,'verbose') && params.verbose
        fprintf('[decision_logic] t=%5.1fs | WL=%.3fm Rate=%.4fm/s SNR=%.1fdB | %s | Fcst=%.2f Risk=%.2f\n',...
            features.timestamp, features.waterLevel, features.rateOfRise, ...
            features.snr, decision.status, decision.forecastLevel, decision.riskProb);
    end
end

function p = smooth_risk(pred, levelAlert, levelFlood)
    span = levelFlood - levelAlert;
    centre = levelFlood;
    steepness = 6 / max(span, 0.1);
    p = 1 / (1 + exp(-steepness * (pred - centre)));
    p = min(max(p, 0), 1);
end

function v = getfield_or(s,f,d)
    if isfield(s,f), v=s.(f); else, v=d; end
end
