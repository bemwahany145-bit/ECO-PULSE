function decision = decision_logic_pro(features, params, history, pro_state)

    if nargin < 3, history = struct(); end
    if nargin < 4, pro_state = struct('bayesLLR', 0); end

    decision = decision_logic(features, params, history);

    try, riskFuzzy = pro_fuzzy_risk(features, params); catch, riskFuzzy = 0; end
    decision.riskFuzzy = riskFuzzy;

    try
        [LLR, bflag] = pro_bayes_detector(features, pro_state.bayesLLR, params);
        pro_state.bayesLLR = LLR;
        decision.bayesLLR  = LLR;
        decision.bayesFlag = bflag;
    catch
        decision.bayesFlag = false;
    end

    w_rule   = 0.35 * double(decision.changeDetected);
    w_fuzzy  = 0.25 * riskFuzzy;
    w_bayes  = 0.20 * double(getfield_or(decision,'bayesFlag',false));
    w_arima  = 0.20 * double(decision.riskProb);
    decision.riskProb = min(1, w_rule + w_fuzzy + w_bayes + w_arima);

    try
        decision.xai = pro_xai_explainer_v2(features, decision, ...
            getfield_or(decision,'lstmAttention',[]));
    catch ME
        warning('decision_logic_pro:xaiV2Failed', ...
            'pro_xai_explainer_v2 failed (%s); falling back to v1.', ME.message);
        try, decision.xai = pro_xai_explainer(features, decision); catch, end
    end

    decision.pro_state = pro_state;
end

function v = getfield_or(s, f, d)
    if isstruct(s) && isfield(s,f), v = s.(f); else, v = d; end
end
