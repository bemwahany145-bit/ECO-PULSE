function export_report(results, params, figList, kpi)

    if nargin<3, figList = findall(0,'Type','figure'); end
    if nargin<4, kpi = []; end
    outfile = getfield_or(params,'report_file','flood_report.pdf');

    if ~isempty(kpi)
        try
            write_kpi_summary_txt(outfile, results, params, kpi);
        catch ME
            warning('export_report: KPI text summary failed: %s', ME.message);
        end
    end

    try
        if exist('mlreportgen.report.Report','class')==8
            rpt = mlreportgen.report.Report(outfile,'pdf');
            tp  = mlreportgen.report.TitlePage;
            tp.Title    = 'Flood Monitoring Radar Report';
            subtitle = sprintf('Scenario: %s  | Final Status: %s', ...
                getfield_or(params,'scenario','?'), ...
                getfield_or(results,'finalStatus','?'));
            if ~isempty(kpi)
                subtitle = [subtitle sprintf('  | Energy: %.3fJ | SNR: %.1fdB', ...
                    getfield_or(kpi,'energyTotalJ',NaN), getfield_or(kpi,'snrMean_dB',NaN))];
            end
            tp.Subtitle = subtitle;
            tp.Author   = 'Radar Team';
            tp.PubDate  = datestr(now,'dd-mmm-yyyy HH:MM');
            add(rpt,tp);
            for i=1:numel(figList)
                f = mlreportgen.report.Figure(figList(i));
                add(rpt,f);
            end
            close(rpt); rptview(rpt);
            fprintf('[export_report] saved -> %s\n', outfile); return;
        end
    catch ME
        warning('Report Generator failed: %s -> using PDF fallback', ME.message);
    end

    try
        if exist('exportgraphics','file')
            if isfile(outfile), delete(outfile); end
            for i=1:numel(figList)
                exportgraphics(figList(i), outfile, 'Append', true);
            end
            fprintf('[export_report] saved -> %s (exportgraphics)\n', outfile);
        else
            for i=1:numel(figList)
                saveas(figList(i), sprintf('flood_report_%d.png', i));
            end
            fprintf('[export_report] saved as PNGs (no exportgraphics available)\n');
        end
    catch ME
        warning('export_report failed: %s', ME.message);
    end
end

function v = getfield_or(s,f,d)
    if isfield(s,f), v=s.(f); else, v=d; end
end

function write_kpi_summary_txt(outfile, results, params, kpi)
    [p,n,~] = fileparts(outfile);
    if isempty(p), p = '.'; end
    txtfile = fullfile(p, [n '_summary.txt']);
    fid = fopen(txtfile,'w');
    if fid < 0, error('could not open %s for writing', txtfile); end
    fprintf(fid, 'GREEN RADAR - EXECUTIVE KPI SUMMARY\n');
    fprintf(fid, 'Generated : %s\n', datestr(now,'dd-mmm-yyyy HH:MM:SS'));
    fprintf(fid, 'Scenario  : %s\n', getfield_or(params,'scenario','?'));
    fprintf(fid, 'Final status : %s\n\n', getfield_or(results,'finalStatus','?'));
    fprintf(fid, '%-32s %s\n', 'Total energy used (J)',      sprintf('%.4f', getfield_or(kpi,'energyTotalJ',NaN)));
    fprintf(fid, '%-32s %s\n', 'Detection-rate proxy (%)',  sprintf('%.2f', getfield_or(kpi,'detectionRatePct',NaN)));
    fprintf(fid, '%-32s %s\n', 'Alarm latency vs truth (s)', sprintf('%.1f', getfield_or(kpi,'alarmLatencyS',NaN)));
    fprintf(fid, '%-32s %s\n', 'Forecast MAE (m)',           sprintf('%.4f', getfield_or(kpi,'forecastMAE_m',NaN)));
    fprintf(fid, '%-32s %s\n', 'Mode 1 (search) time (%)',  sprintf('%.1f', getfield_or(kpi,'dutyMode1Pct',NaN)));
    fprintf(fid, '%-32s %s\n', 'Mode 2 (track) time (%)',   sprintf('%.1f', getfield_or(kpi,'dutyMode2Pct',NaN)));
    fprintf(fid, '%-32s %s\n', 'SNR mean/min/max (dB)',      sprintf('%.1f / %.1f / %.1f', ...
        getfield_or(kpi,'snrMean_dB',NaN), getfield_or(kpi,'snrMin_dB',NaN), getfield_or(kpi,'snrMax_dB',NaN)));
    fprintf(fid, '%-32s %s\n', 'Battery projection (hours)', sprintf('%.1f', getfield_or(kpi,'batteryProjHours',NaN)));
    fclose(fid);
    fprintf('[export_report] KPI summary saved -> %s\n', txtfile);
end
