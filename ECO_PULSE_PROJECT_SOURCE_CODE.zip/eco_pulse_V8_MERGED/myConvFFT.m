function y = myConvFFT(x, h, shape)

    if nargin < 3, shape = 'full'; end
    x = x(:); h = h(:);
    N = length(x) + length(h) - 1;
    Y = ifft(fft(x, N) .* fft(h, N));
    switch lower(shape)
        case 'full'
            y = Y;
        case 'same'
            startIdx = floor((length(h)-1)/2) + 1;
            y = Y(startIdx:startIdx + length(x) - 1);
        case 'valid'
            startIdx = length(h);
            endIdx = length(x);
            if endIdx >= startIdx, y = Y(startIdx:endIdx);
            else, y = []; end
        otherwise
            error('Invalid shape. Use full, same, or valid.');
    end
end
