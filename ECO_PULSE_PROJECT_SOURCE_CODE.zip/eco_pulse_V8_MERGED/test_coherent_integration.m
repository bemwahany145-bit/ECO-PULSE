function result = test_coherent_integration(params, Np)

    if nargin<1, params = get_params('fast_rise'); end
    if nargin<2, Np = params.num_pulses; end

    result = struct('ok',false);
    try
        p = params; p.num_pulses = Np;
        [tx, tx_matrix, ~] = signal_generation(1, p);
        [rx, meta] = environment_model(tx, p, 0);

        L_pri = size(tx_matrix,1);
        single_period_template = tx_matrix(:,1);

        nAvail = floor(length(rx)/L_pri);
        nUse = min(Np, nAvail);
        if nUse < 2
            error('not enough samples for >=2 pulses (L_pri=%d, len(rx)=%d)', L_pri, length(rx));
        end
        slow = reshape(rx(1:L_pri*nUse), L_pri, nUse);

        mf = conj(flipud(single_period_template));
        single_mf = abs(myConvFFT(slow(:,1), mf, 'same'));
        snr_single = measure_snr(single_mf);

        coherent_sum = sum(slow, 2);
        coh_mf = abs(myConvFFT(coherent_sum, mf, 'same'));
        snr_coherent = measure_snr(coh_mf);

        noncoh = zeros(size(single_mf));
        for k = 1:nUse
            noncoh = noncoh + abs(myConvFFT(slow(:,k), mf, 'same'));
        end
        snr_noncoherent = measure_snr(noncoh);

        result.ok = true;
        result.Np_used          = nUse;
        result.snr_single_dB    = snr_single;
        result.snr_coherent_dB  = snr_coherent;
        result.snr_noncoh_dB    = snr_noncoherent;
        result.gain_coherent_dB    = snr_coherent   - snr_single;
        result.gain_noncoherent_dB = snr_noncoherent - snr_single;
        result.theoretical_gain_dB = 10*log10(nUse);

        fprintf('\n--- Coherent Pulse Integration (Np=%d) ---\n', nUse);
        fprintf('  Single-pulse SNR      : %6.2f dB\n', snr_single);
        fprintf('  Coherent-sum SNR      : %6.2f dB  (measured gain %+.2f dB, theory %+.2f dB)\n', ...
            snr_coherent, result.gain_coherent_dB, result.theoretical_gain_dB);
        fprintf('  Non-coherent-sum SNR  : %6.2f dB  (measured gain %+.2f dB)\n', ...
            snr_noncoherent, result.gain_noncoherent_dB);
    catch e
        result.ok = false; result.error = e.message;
        fprintf('  Coherent integration test FAILED: %s\n', e.message);
    end
end

function snr_dB = measure_snr(mfAbs)
    peakVal    = max(mfAbs);
    noiseFloor = max(median(mfAbs), eps);
    snr_dB = 20*log10(max(peakVal,eps)/noiseFloor);
end
