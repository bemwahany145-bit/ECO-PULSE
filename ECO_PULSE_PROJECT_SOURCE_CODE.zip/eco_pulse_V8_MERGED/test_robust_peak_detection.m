function result = test_robust_peak_detection(params, nTrials)

    if nargin<1, params = get_params('fast_rise'); end
    if nargin<2, nTrials = 20; end

    errGlobalMax = zeros(nTrials,1); errFirstPeak = zeros(nTrials,1);
    fprintf('\n--- Robust (first-peak) vs Naive (global-max) Detection, n=%d trials ---\n', nTrials);
    for i = 1:nTrials
        try
            rng(20000+i);
            p = params;
            [tx, ~, ~] = signal_generation(1, p);
            [rx, meta] = environment_model(tx, p, 0);
            trueRange = meta.range;

            mf = conj(flipud(tx));
            mfAbs = abs(myConvFFT(rx, mf, 'same'));

            [~, idxGlobal] = max(mfAbs);
            rangeGlobal = (idxGlobal-1) / p.samplesPerMeter;

            idxFirst = first_significant_peak(mfAbs, 6);
            rangeFirst = (idxFirst-1) / p.samplesPerMeter;

            errGlobalMax(i) = abs(rangeGlobal - trueRange);
            errFirstPeak(i) = abs(rangeFirst  - trueRange);
        catch e
            errGlobalMax(i) = NaN; errFirstPeak(i) = NaN;
            fprintf('  trial %d FAILED: %s\n', i, e.message);
        end
    end

    result.ok = true;
    result.rmse_globalmax_m = sqrt(mean(errGlobalMax(~isnan(errGlobalMax)).^2));
    result.rmse_firstpeak_m = sqrt(mean(errFirstPeak(~isnan(errFirstPeak)).^2));
    result.improvementPct = 100*(result.rmse_globalmax_m - result.rmse_firstpeak_m) / max(result.rmse_globalmax_m,eps);

    fprintf('  Naive global-max (current pipeline) RMSE : %.3f m\n', result.rmse_globalmax_m);
    fprintf('  First-significant-peak (proposed) RMSE   : %.3f m\n', result.rmse_firstpeak_m);
    fprintf('  Improvement                                : %+.1f %%\n', result.improvementPct);
    fprintf('  (Root cause: params.multipath=true by default - a later multipath\n');
    fprintf('   return can exceed the true direct-path peak in amplitude. This is a\n');
    fprintf('   candidate fix for signal_processing.m''s range-estimation step, NOT\n');
    fprintf('   yet applied to the live pipeline - see chat for why.)\n');
end

function idx = first_significant_peak(mfAbs, thresholdDb)
    noiseFloor = median(mfAbs);
    thresh = noiseFloor * 10^(thresholdDb/10);
    N = numel(mfAbs);
    idx = 0;
    for k = 2:N-1
        if mfAbs(k) > thresh && mfAbs(k) >= mfAbs(k-1) && mfAbs(k) >= mfAbs(k+1)
            idx = k; return;
        end
    end
    if idx == 0
        [~, idx] = max(mfAbs);
    end
end
