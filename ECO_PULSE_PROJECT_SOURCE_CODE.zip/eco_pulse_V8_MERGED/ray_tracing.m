function rx_out = ray_tracing(rx_in, tx_signal, currentRange, params)

    rx_out = rx_in;
    if ~getfield_or(params,'raytracing',false), return; end

    N = length(rx_in);
    wallOffset = [6 10];
    reflCoef   = [0.07 0.05];
    for i = 1:numel(wallOffset)
        R = currentRange + wallOffset(i);
        d = round(R * params.samplesPerMeter);
        if d < N
            att = 1/(R^2+1);
            rx_out(d+1:end) = rx_out(d+1:end) + att*reflCoef(i)*tx_signal(1:N-d);
        end
    end
end

function v = getfield_or(s,f,d)
    if isfield(s,f), v=s.(f); else, v=d; end
end
