function pro_ar_export(params, filename)
    if nargin<2, filename = 'radar_scene.obj'; end
    [X,Y] = meshgrid(linspace(-30,30,60), linspace(-15,30,60));
    Z = 0.15*abs(X) + 0.03*Y + 0.5*exp(-(X.^2+Y.^2)/400);
    [R,C] = size(Z);
    fid = fopen(filename, 'w');
    if fid < 0, fprintf('[pro_ar_export] cannot open %s\n', filename); return; end
    fprintf(fid, '# Radar Ultimate · AR scene\n');
    for i=1:R, for j=1:C
        fprintf(fid, 'v %.3f %.3f %.3f\n', X(i,j), Y(i,j), Z(i,j));
    end, end
    for i=1:R-1, for j=1:C-1
        a=(i-1)*C+j; b=a+1; c=i*C+j; d=c+1;
        fprintf(fid, 'f %d %d %d\n', a,b,c);
        fprintf(fid, 'f %d %d %d\n', b,d,c);
    end, end
    fclose(fid);
    fprintf('[pro_ar_export] OBJ written: %s  (%dx%d mesh)\n', filename, R, C);
end
