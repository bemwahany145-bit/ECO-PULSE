function exp = pro_xai_explainer(features, decision)

    names = {'SNR','level','vz','cfar','peakW','rate'};

    snr_val   = getf(features, 'snr',         15);
    level_val = getf(features, 'waterLevel',   0.5);
    vz_val    = abs(getf(features, 'surfaceVz', 0));
    cfar_val  = getf(features, 'cfarTargets',  0);
    peak_val  = getf(features, 'peakWidth',    0);
    rate_val  = getf(features, 'rateOfRise',   0);
    fcst_val  = getf(decision,  'forecastLevel', level_val);

    vals = [snr_val, level_val, vz_val, cfar_val, peak_val, rate_val];

    base = [15,   ...
            0.5,  ...
            0.05, ...
            0,    ...
            0.12, ...
            0.0];

    norm_base = max(abs(base), [1, 0.5, 0.01, 1, 0.05, 0.005]);

    w = [0.15, 0.35, 0.05, 0.10, 0.10, 0.25];

    delta   = vals - base;
    contrib = w .* (delta ./ norm_base);

    contrib = max(min(contrib, 1), -1);

    [~, idx] = sort(abs(contrib), 'descend');

    exp.names        = names;
    exp.values       = vals;
    exp.contrib      = contrib;
    exp.ranked       = idx;
    exp.top1         = names{idx(1)};
    exp.top1_contrib = contrib(idx(1));
    exp.forecastLevel = fcst_val;
end

function v = getf(s, f, def)
    if isstruct(s) && isfield(s, f), v = s.(f); else, v = def; end
end
