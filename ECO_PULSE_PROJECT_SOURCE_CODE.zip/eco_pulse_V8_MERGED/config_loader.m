function cfg = config_loader(filename)

    cfg = struct();
    if nargin < 1 || isempty(filename) || ~exist(filename,'file')
        warning('config_loader: file not found, returning defaults.');
        return;
    end

    [~,~,ext] = fileparts(filename);
    switch lower(ext)
        case '.json'
            txt = fileread(filename);
            cfg = jsondecode(txt);
        case {'.yml','.yaml'}
            if exist('yaml.ReadYaml','file') || exist('ReadYaml','file')
                try
                    cfg = yaml.ReadYaml(filename);
                catch
                    cfg = ReadYaml(filename);
                end
            else
                error('config_loader: YAML toolbox not found.');
            end
        otherwise
            error('config_loader: unsupported extension %s', ext);
    end
end
