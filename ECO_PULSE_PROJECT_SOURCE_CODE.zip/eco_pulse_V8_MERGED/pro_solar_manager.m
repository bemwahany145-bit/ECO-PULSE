function [sol, battState] = pro_solar_manager(t, dE_used_J, params, battState)

    if nargin < 4 || isempty(battState)
        battState = struct('cum_used_J', 0, 'cum_harvested_J', 0);
    end

    solar_W = getfield_or(params,'solar_panel_W', 30);
    cap_Wh  = getfield_or(params,'battery_capacity_Wh', 50);
    hour = mod(t/3600, 24);
    if hour >= 6 && hour <= 18
        irr = sin(pi*(hour-6)/12);
    else
        irr = 0;
    end

    sol.solar_W     = irr * solar_W;
    sol.harvested_J = sol.solar_W * params.dt;

    battState.cum_used_J      = battState.cum_used_J + max(0,dE_used_J);
    battState.cum_harvested_J = battState.cum_harvested_J + sol.harvested_J;

    cap_J = cap_Wh * 3600;
    net_J = cap_J - battState.cum_used_J + battState.cum_harvested_J;
    sol.battery_pct  = max(0, min(100, 100*net_J/cap_J));
    sol.sustainability = battState.cum_harvested_J / max(1e-6, battState.cum_used_J);
end

function v = getfield_or(s,f,d), if isstruct(s) && isfield(s,f), v=s.(f); else, v=d; end; end
