# Known Limitations — Documented for Transparency

This file exists because the hackathon rules require every AI-assisted or
external element of this project to be explainable and disclosed. It
documents one real limitation found during a full signal-processing audit
(`compare_windows.m`), the root cause, why it was NOT fixed before the
submission deadline, and the correct fix path for later.

## Limitation: Mode-2 (chirp) pulse is under-sampled

**What we found:** `params.fs = 10 kHz` and `params.pulse_repetition_interval
= 1 ms` together give a hard ceiling of `PRI * fs = 10 samples` for an
ENTIRE pulse repetition interval (transmit pulse + silence). At `duty_cycle
= 0.05`, the Mode-2 LFM chirp pulse itself (`Lp = duty * PRI * fs`) works
out to **0.5 samples** — i.e. the chirp is not actually represented as a
swept-frequency waveform in the time-domain generator; it degenerates to a
near-impulse. We verified this directly: running the real matched filter on
the actual generated waveform gives a Peak Sidelobe Ratio of only -0.45 dB
(a healthy windowed pulse should be -13 dB or better), and the result is
IDENTICAL across all 4 supported window types (hann/kaiser/chebwin/
taylorwin) — because there is no real pulse shape left for a window to act
on.

Separately, `params.chirp_bandwidth = 20 MHz` vastly exceeds the Nyquist
limit implied by `fs = 10 kHz` (which would need `fs >= 40 MHz` for a
faithfully-sampled 20 MHz-wide complex chirp), so even fixing the sample
count alone would not make the waveform physically faithful to a real 20
MHz RF sweep.

**What is NOT affected:** Mode-1 (Zadoff-Chu) pulses use a fixed length
(`params.zc_length = 127` samples) independent of `fs`/`duty`/`PRI`, so
they are not degenerate. Detection logic, CFAR, tracking, and the paired
efficiency/quality KPIs all operate on higher-level derived quantities
(SNR, range estimate, risk score) that remain internally self-consistent
and were validated end-to-end (all 5 scenarios, Monte Carlo Pd/Pfa,
baseline-vs-green comparison, and a 6-case stress test all pass) - this
limitation affects the *physical realism of the raw Mode-2 waveform only*,
not the stability or the validated top-level results.

**Why we did not fix it before the deadline:** the only real fix requires
raising `fs` by 2-3 orders of magnitude, which touches range/Doppler
formulas in `environment_model.m`, `signal_processing.m`, and
`music_esprit.m`, and its real-world runtime impact on the actual demo
machine could not be verified in the available time. Changing a
foundational sampling parameter without the ability to fully re-verify
performance and correctness everywhere it is used was judged a bigger risk
to a stable live demo than leaving the limitation documented.

**What we did about it (deadline extended, so we could do this properly):**
We wired in a genuine, opt-in, disclosed alternative: `params.range_estimation_mode`.
- `'ground_truth'` (**default, unchanged**): exactly the behaviour documented
  above. Every validation run in this project (Pd/Pfa, baseline-vs-green
  across all 5 scenarios, the full stress-test suite) uses this and was
  re-confirmed bit-for-bit identical after this change (same energy
  values: stable=0.483J, slow_rise=1.809J, fast_rise=2.075J,
  receding=1.271J, flash_flood=1.653J).
- `'signal_based'` (opt-in): forces `signal_processing.m` and
  `feature_extraction.m` to actually use the real matched-filter output,
  with the track-before-detect gating validated in
  `test_track_before_detect.m` (Kalman-predicted range gates which
  candidate peak is physically plausible). We ran the FULL pipeline in
  this mode across all 5 scenarios: it does not crash, but it is
  measurably NOT accurate enough to drive the decision logic reliably -
  e.g. the `stable` scenario (water level should stay ~0.5 m) incorrectly
  reaches `flood_risk` because of the ~7 m range ambiguity documented
  above. This is an honest, expected result given the multipath analysis,
  not a new bug.

**Recommendation:** keep `'ground_truth'` as the operational default for
the live demo (safe, already fully validated). `'signal_based'` is left
in the codebase, tested, and disclosed as evidence of genuine signal-layer
capability - useful to show a judge who asks "can you actually measure
range from the signal, or is it simulated?" (answer: both exist, we
measured the real one's limitations honestly, and made a deliberate,
documented choice for which one drives the demo).

**UPDATE (V8):** the team independently found and fixed the true root cause
via their own Range Profile / RD-map screenshot review (FIX-10, FIX-11,
FIX-12 in signal_processing.m / get_params.m):
- FIX-10: raised `pulse_repetition_interval` so one PRI's sample count
  comfortably exceeds the max possible target delay, eliminating range-
  ambiguity folding.
- FIX-11/12: matched filter now uses a single-PRI, active-pulse-only
  reference (not the whole multi-pulse burst, and not padded with the
  inter-pulse silent gap), removing the periodic comb of ghost peaks and
  a large constant range bias.
- FIX-14 (signal_generation.m): frequency agility now hops per burst/CPI
  instead of per pulse-within-burst, restoring slow-time phase coherence
  for Doppler processing.

We re-tested `range_estimation_mode='signal_based'` on top of these fixes:
the `stable` scenario now correctly stays at `monitoring` (previously it
incorrectly reached `flood_risk`), and `slow_rise`/`fast_rise` track
reasonably close to the true water level using the REAL signal path. This
is a genuine, verified improvement - the multipath/ambiguity problem
documented below is substantially mitigated by these fixes, though
`ground_truth` remains the safer default for the live demo since it has
been the most thoroughly validated end-to-end.

## Limitation: range peak-picking is ambiguous under default multipath settings

**What we found:** with `params.multipath = true` (the default), the matched-
filter output often contains several PERIODIC peaks (~11 samples apart in
our tests) within about 1 dB of each other's amplitude - the true
direct-path target is not reliably the strongest one. We verified this by
comparing the pipeline's current approach (naive global maximum) against
a "first significant peak above threshold" alternative across 20 trials at
near-ideal SNR (60 dB): global-max gave 7.25 m RMSE, and the "smarter"
first-peak heuristic actually made it WORSE (10.66 m RMSE, a -47% change) -
because when candidate peaks are this close in amplitude, a simple
threshold-based heuristic is effectively picking among near-equal options
almost at random, no better than picking the strongest one.

We also confirmed (`test_subbin_interpolation.m`) that parabolic sub-bin
interpolation gives 0% improvement here - because the dominant error is
NOT sub-sample quantization jitter, it is this gross ambiguity between
peaks that are metres apart. Sub-bin interpolation only helps once the
correct peak is already being selected.

**Why we did not "fix" this before the deadline:** every heuristic we
tried and tested (see above) either did not help or actively hurt
accuracy. A real fix needs either (a) exploiting the KNOWN periodic
spacing of the multipath ghosts to identify and reject them specifically
(the ~11-sample spacing looks like a standing-wave/reverberation pattern
tied to the water surface geometry, not random noise), or (b) using the
Kalman tracker's existing prior range estimate to gate which candidate
peak is physically plausible given the last known target position -
i.e. track-before-detect logic. Both are legitimate, real fixes but are
multi-hour undertakings requiring their own validation, not a same-day
patch, and shipping an untested heuristic that we already measured as
WORSE would be actively dishonest.

**What this does NOT affect:** the top-level KPIs already validated (Pd/
Pfa via Monte Carlo, baseline-vs-green energy comparison, alarm timing)
because those depend on the Kalman-filtered decision pipeline's higher-level
risk assessment, not on raw single-pulse range precision - and they were
independently verified end-to-end across all 5 scenarios with no crashes.


## Fixed during V8 merge: zero-length pulse edge case

While re-running the stress-test suite (`run_full_validation.m`) after
merging today's audit work onto V8's improved core, an extreme
`duty_cycle=1e-6` case crashed (`Y(0): subscripts must be either integers
1 to (2^63)-1 or logicals`, in `myConvFFT` via `signal_processing.m`).
Root cause: V8's larger `pulse_repetition_interval` (FIX-10) means
`Lp = round(duty_cycle * PRI * fs)` can now round to exactly 0 samples at
very low duty cycles, producing a zero-length matched-filter template.
Fixed with a `max(1, ...)` floor in both `signal_processing.m` and
`signal_generation.m`. Verified: the crash is gone and normal scenarios
are unaffected (energy values unchanged).
