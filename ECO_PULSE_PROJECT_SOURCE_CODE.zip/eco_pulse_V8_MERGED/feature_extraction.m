function features = feature_extraction(proc, prevLevel, params, meta, kalmanState)

    if nargin < 4, meta = []; end
    if nargin < 5, kalmanState = []; end

    if ~isstruct(proc), error('proc must be a struct.'); end
    if ~isfield(params,'dt') || ~isfield(params,'snrThreshold')
        error('Missing dt or snrThreshold.');
    end

    rangeMode = getfield_or(params,'range_estimation_mode','ground_truth');
    if ~strcmpi(rangeMode,'signal_based') && ~isempty(meta) && isfield(meta,'waterLevel') && isfield(meta,'range')
        currentLevel = meta.waterLevel;
        currentRange = meta.range;
    else
        if ~isfield(proc,'estimatedRange')
            error('proc.estimatedRange required if meta is missing.');
        end
        currentRange = proc.estimatedRange;
        currentLevel = max(params.mountHeight - currentRange, 0);
    end

    if isstruct(meta) && isfield(meta,'surface_vz')
        surfVz = meta.surface_vz;
    else
        surfVz = 0;
    end

    if getfield_or(params,'kalman_enabled',false) && exist('kalman_tracker','file')
        [xEst, kalmanState] = kalman_tracker(currentLevel, params.dt, kalmanState, surfVz, params);
        currentLevel_kal = xEst(1);
        rateOfRise_kal   = xEst(2);
    else
        currentLevel_kal = currentLevel;
        rateOfRise_kal   = NaN;
    end

    if isempty(prevLevel) || isnan(prevLevel)
        deltaLevel = 0; rateOfRise_raw = 0;
    else
        deltaLevel = currentLevel - prevLevel;
        rateOfRise_raw = deltaLevel / params.dt;
    end

    if ~isnan(rateOfRise_kal)
        rateOfRise = rateOfRise_kal;
    else
        rateOfRise = rateOfRise_raw;
    end

    if isfield(proc,'snrEst_dB'), snr = proc.snrEst_dB; else, snr = 0; end
    confidence = double(snr >= params.snrThreshold);

    if rateOfRise > 0.02, trend = "rising";
    elseif rateOfRise < -0.02, trend = "falling";
    else, trend = "stable"; end

    peakWidth = 0;
    if isfield(proc,'range_profile') && ~isempty(proc.range_profile)
        rp = proc.range_profile;
        [pv,pi] = max(rp);
        if pv>0
            half = pv/sqrt(2);
            l = find(rp(1:pi)<half,1,'last');     if isempty(l), l = 1;        end
            r = find(rp(pi:end)<half,1,'first') + pi - 1; if isempty(r), r = length(rp); end
            peakWidth = (r-l)/params.samplesPerMeter;
        end
    end

    if isfield(proc,'cfar_mask'), cfarTargets = nnz(proc.cfar_mask); else, cfarTargets = 0; end

    waterDopplerRatio = 0;
    if isfield(proc,'rd_map') && ~isempty(proc.rd_map)
        rd_map = proc.rd_map;
        nRangeBins = size(rd_map,1);
        if nRangeBins >= 7
            water_range_bin = mod(round(currentRange*params.samplesPerMeter) - 1, nRangeBins) + 1;
            guard = min(3, floor((nRangeBins-1)/2));
            lo = max(1, water_range_bin - guard + 1);
            hi = min(nRangeBins, water_range_bin + guard - 1);
            doppler_energy = sum(abs(rd_map(water_range_bin,:)).^2);
            others = setdiff(1:nRangeBins, lo:hi);
            if ~isempty(others)
                clutter_energy = mean(sum(abs(rd_map(others,:)).^2, 2));
            else
                clutter_energy = mean(abs(rd_map(:)).^2);
            end
            waterDopplerRatio = doppler_energy / (clutter_energy + eps);
        end
    end

    features = struct();
    features.waterLevel     = currentLevel_kal;
    features.waterLevel_raw = currentLevel;
    features.rateOfRise     = rateOfRise;
    features.rateOfRise_raw = rateOfRise_raw;
    features.deltaLevel     = deltaLevel;
    features.snr            = snr;
    features.confidence     = confidence;
    features.range          = currentRange;
    features.trend          = trend;
    features.surfaceVz      = surfVz;
    features.peakWidth      = peakWidth;
    features.cfarTargets    = cfarTargets;
    features.waterDopplerRatio = waterDopplerRatio;
    features.kalmanState    = kalmanState;
end

function v = getfield_or(s,f,d)
    if isfield(s,f), v=s.(f); else, v=d; end
end
