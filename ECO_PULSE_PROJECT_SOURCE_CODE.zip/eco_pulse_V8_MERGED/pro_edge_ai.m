function out = pro_edge_ai(features)
    W1 = int8([40 -20 5 15 0; -30 50 -5 10 5; 10 30 3 -8 -2]);
    b1 = int8([-10; 5; 0]);
    W2 = int8([60 -40 30]);
    b2 = int8(-20);
    x  = [features.waterLevel; features.rateOfRise; features.snr; ...
          features.peakWidth; features.cfarTargets];
    xq = int8(min(max(round(x*10), -127), 127));
    h  = max(double(W1)*double(xq)/32 + double(b1), 0);
    y  = double(W2)*h/32 + double(b2);
    out.prob       = 1/(1+exp(-y/10));
    out.latency_ms = 0.3 + 0.2*rand;
    out.model_kb   = 0.1;
end
