function label = ml_classifier(features, params)

    fv = [features.waterLevel, features.rateOfRise, ...
          features.snr, features.peakWidth, features.cfarTargets, ...
          features.surfaceVz];

    mdlPath = '';
    if isfield(params,'ml_model_path'), mdlPath = params.ml_model_path; end
    if ~isempty(mdlPath) && exist(mdlPath,'file')
        try
            S = load(mdlPath);
            names = fieldnames(S);
            mdl = S.(names{1});
            label = string(predict(mdl, fv));
            return;
        catch
        end
    end

    s = 0;
    s = s + sigmoid(2*(features.waterLevel-params.levelAlert));
    s = s + sigmoid(200*(features.rateOfRise-params.rateAlert));
    s = s + 0.5*sigmoid(features.cfarTargets-1);
    s = s - 0.3*sigmoid(params.snrThreshold-features.snr);

    if s > 2.5
        label = "flood_risk";
    elseif s > 1.2
        label = "alert";
    else
        label = "monitoring";
    end
end

function y = sigmoid(x)
    y = 1 ./ (1 + exp(-x));
end
