function [pred, h_T, cache] = lstm_forecast_forward(Xseq, W, norm)

    [nx, T] = size(Xseq);
    nh = size(W.Wf,1);

    Xn = zeros(nx,T);
    Xn(1,:) = (Xseq(1,:) - norm.mu_l)    / norm.sg_l;
    Xn(2,:) = (Xseq(2,:) - norm.mu_r)    / norm.sg_r;
    Xn(3,:) = (Xseq(3,:) - norm.mu_rain) / norm.sg_rain;

    h = zeros(nh,1); c = zeros(nh,1);
    cache.z=cell(1,T); cache.f=cell(1,T); cache.i=cell(1,T); cache.o=cell(1,T);
    cache.g=cell(1,T); cache.c=cell(1,T); cache.cprev=cell(1,T); cache.h=cell(1,T);
    for t = 1:T
        z = [h; Xn(:,t)];
        f = sigmoid_(W.Wf*z + W.bf);
        i = sigmoid_(W.Wi*z + W.bi);
        o = sigmoid_(W.Wo*z + W.bo);
        g = tanh(W.Wc*z + W.bc);
        cprev = c;
        c = f.*cprev + i.*g;
        h = o.*tanh(c);

        cache.z{t}=z; cache.f{t}=f; cache.i{t}=i; cache.o{t}=o;
        cache.g{t}=g; cache.c{t}=c; cache.cprev{t}=cprev; cache.h{t}=h;
    end
    h_T = h;
    pred_n = W.Wy*h + W.by;
    pred = pred_n * norm.sg_l + norm.mu_l;
end

function y = sigmoid_(x), y = 1./(1+exp(-x)); end
