function results = compare_windows(params)

    if nargin<1, params = get_params(); end

    windows = {'hann','kaiser','chebwin','taylorwin'};
    results = struct('window',{},'PSLR_dB',{},'mainlobe3dB_samples',{});

    fprintf('\n--- Window comparison (matched-filter PSLR / mainlobe width) ---\n');
    for i = 1:numel(windows)
        p = params;
        p.window_type = windows{i};
        try
            [tx, ~, ~] = signal_generation(2, p);
            mf = conv(tx, conj(flipud(tx)));
            mfAbs = abs(mf);
            mfAbs = mfAbs / max(mfAbs);
            [pk, pkIdx] = max(mfAbs);

            excludeHalfWidth = max(3, round(0.01*numel(mfAbs)));
            sideRegion = mfAbs;
            loIdx = max(1, pkIdx-excludeHalfWidth); hiIdx = min(numel(mfAbs), pkIdx+excludeHalfWidth);
            sideRegion(loIdx:hiIdx) = 0;
            pslr_dB = 20*log10(max(sideRegion) / pk + eps);

            half = pk/sqrt(2);
            leftIdx  = find(mfAbs(1:pkIdx) < half, 1, 'last');
            rightRel = find(mfAbs(pkIdx:end) < half, 1, 'first');
            if isempty(leftIdx), leftIdx = 1; end
            if isempty(rightRel), rightIdx = numel(mfAbs); else, rightIdx = pkIdx+rightRel-1; end
            mainlobeWidth = rightIdx - leftIdx;

            results(i).window = windows{i};
            results(i).PSLR_dB = pslr_dB;
            results(i).mainlobe3dB_samples = mainlobeWidth;
            fprintf('  %-10s  PSLR = %7.2f dB   mainlobe(-3dB) = %4d samples\n', ...
                windows{i}, pslr_dB, mainlobeWidth);
        catch e
            results(i).window = windows{i};
            results(i).PSLR_dB = NaN; results(i).mainlobe3dB_samples = NaN;
            fprintf('  %-10s  FAILED: %s\n', windows{i}, e.message);
        end
    end

    valid = ~isnan([results.PSLR_dB]);
    if any(valid)
        [~,bestIdx] = min([results(valid).PSLR_dB]);
        validNames = {results(valid).window};
        fprintf('\nBest sidelobe suppression: %s (lowest PSLR).\n', validNames{bestIdx});
        fprintf('Trade-off: better PSLR generally costs mainlobe width (range resolution) - see table above.\n');
    end
end
