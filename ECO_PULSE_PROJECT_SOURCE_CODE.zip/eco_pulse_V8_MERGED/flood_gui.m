function flood_gui(results, params)

    fig = uifigure('Name','Flood Monitoring - GUI','Position',[120 80 1400 820]);
    gl  = uigridlayout(fig,[1 1]); tg = uitabgroup(gl);

    t1 = uitab(tg,'Title','Overview');
    g1 = uigridlayout(t1,[3 2],'RowHeight',{'1x','1x','fit'});
    ax1 = uiaxes(g1); ax1.Layout.Row=1; ax1.Layout.Column=1;
    plot(ax1, results.time, results.waterLevel,'b-','LineWidth',1.8);
    hold(ax1,'on');
    yline(ax1, params.levelAlert, '--','Alert','Color',[1 0.6 0]);
    yline(ax1, params.levelFlood, '--','Flood','Color',[0.9 0 0]);
    title(ax1,'Water Level'); xlabel(ax1,'Time (s)'); ylabel(ax1,'m'); grid(ax1,'on');

    ax2 = uiaxes(g1); ax2.Layout.Row=1; ax2.Layout.Column=2;
    stairs(ax2, results.time, results.state,'g','LineWidth',1.8);
    yticks(ax2,[0 1 2]); yticklabels(ax2,{'Monit','Alert','Flood'});
    title(ax2,'State'); grid(ax2,'on');

    ax3 = uiaxes(g1); ax3.Layout.Row=2; ax3.Layout.Column=1;
    if isfield(results,'riskProb')
        plot(ax3, results.time, results.riskProb,'m-','LineWidth',1.8);
        ylim(ax3,[0 1]); title(ax3,'Risk Probability'); grid(ax3,'on');
    end

    ax4 = uiaxes(g1); ax4.Layout.Row=2; ax4.Layout.Column=2;
    if isfield(results,'snr')
        plot(ax4, results.time, results.snr,'r-','LineWidth',1.5);
        title(ax4,'SNR (dB)'); grid(ax4,'on');
    end

    lbl = uilabel(g1,'Text',sprintf('FINAL STATUS: %s', upper(results.finalStatus)), ...
                  'FontSize',20,'FontWeight','bold');
    lbl.Layout.Row=3; lbl.Layout.Column=[1 2];
    switch lower(results.finalStatus)
        case 'alert',      lbl.BackgroundColor=[1 0.75 0.15];
        case 'flood_risk', lbl.BackgroundColor=[1 0.3 0.3];
        otherwise,         lbl.BackgroundColor=[0.85 1 0.85];
    end

    t2 = uitab(tg,'Title','Range-Doppler');
    ax5 = uiaxes(t2,'Position',[40 40 1300 700]);
    if isfield(results,'rdMap') && ~isempty(results.rdMap)
        imagesc(ax5, 20*log10(results.rdMap+eps));
        colorbar(ax5); colormap(ax5,'jet');
        title(ax5,'Range-Doppler Map (dB)');
        xlabel(ax5,'Doppler bin'); ylabel(ax5,'Range bin');
    else
        uilabel(t2,'Text','No Range-Doppler data.','Position',[40 400 400 30], ...
                'FontSize',14);
    end

    t3 = uitab(tg,'Title','Parameters');
    fnames = fieldnames(params);
    data = cell(numel(fnames),2);
    for i=1:numel(fnames)
        data{i,1} = fnames{i};
        v = params.(fnames{i});
        if isnumeric(v) || islogical(v), v = num2str(v(:)'); end
        if isstring(v) || ischar(v), v = char(v); end
        if iscell(v) || isstruct(v), v = '<complex>'; end
        data{i,2} = v;
    end
    uitable(t3,'Data',data,'ColumnName',{'Parameter','Value'}, ...
            'Position',[40 40 1300 720],'FontSize',11);

    t4 = uitab(tg,'Title','Export');
    uilabel(t4,'Text','Export all figures to PDF report:', ...
            'Position',[40 700 400 30],'FontSize',14);
    uibutton(t4,'Text','Export PDF','Position',[40 640 200 40], ...
             'ButtonPushedFcn',@(btn,event)export_report(results,params));

    disp('[flood_gui] GUI launched.');
end
