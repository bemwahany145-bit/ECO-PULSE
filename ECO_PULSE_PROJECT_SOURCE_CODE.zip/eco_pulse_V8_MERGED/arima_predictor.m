function [pred, pStd] = arima_predictor(history, features, params)

    horizon = params.forecast_horizon_s;
    histLen = params.forecast_history_s;

    minStd = max(0.05 * (params.levelFlood - params.levelAlert), 0.01);

    if ~isfield(history,'levelBuffer') || isempty(history.levelBuffer)
        pred = features.waterLevel + features.rateOfRise*horizon;
        pStd = minStd;
        return;
    end

    buf = history.levelBuffer(:);
    if length(buf) < 4
        pred = features.waterLevel + features.rateOfRise*horizon;
        pStd = minStd;
        return;
    end

    used_arima = false;
    try
        if exist('arima','class')==8 || exist('arima','file')==2
            mdl = arima('ARLags',1,'D',1,'MALags',1);
            estMdl = estimate(mdl, buf, 'Display','off');
            [Y,YMSE] = forecast(estMdl, horizon, 'Y0', buf);
            pred = Y(end);
            pStd = max(sqrt(YMSE(end)), minStd);
            used_arima = true;
        end
    catch
    end

    if ~used_arima
        n = length(buf);
        t = (0:n-1)' * params.dt;
        A = [t ones(n,1)];
        theta = A \ buf;
        t_future = t(end) + horizon;
        pred = theta(1)*t_future + theta(2);
        resid = buf - A*theta;
        pStd = max(std(resid), minStd);
    end
end
