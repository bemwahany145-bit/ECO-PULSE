function result = compare_conventional_vs_smart(scenario, doPlot)

    if nargin<1 || isempty(scenario), scenario = 'fast_rise'; end
    if nargin<2, doPlot = false; end

    result = struct('ok', false, 'scenario', scenario);
    try
        p = get_params(scenario);
        seed = sum(double(scenario)) + 2000;

        rng(seed);
        rSmart = main_flood_monitoring_system_core(p);

        rng(seed);
        rConv = simulate_conventional_radar(p, numel(rSmart.time));

        t = rSmart.time;
        truth = trueWaterLevel_local(t, p.scenario, p.rise_rate);

        rmseSmart = sqrt(mean((rSmart.waterLevelKalman - truth).^2));
        rmseConv  = sqrt(mean((rConv.levelRaw          - truth).^2));

        flipsSmart = count_flips(rSmart.state);
        flipsConv  = count_flips(rConv.state);

        idxTrueAlert = find(truth >= p.levelAlert, 1, 'first');
        idxSmart = find(rSmart.state >= 1, 1, 'first');
        idxConv  = find(rConv.state  >= 1, 1, 'first');
        latSmart = latency(t, idxTrueAlert, idxSmart);
        latConv  = latency(t, idxTrueAlert, idxConv);

        result.ok = true;
        result.smart.rmse_m = rmseSmart;
        result.smart.falseAlarmFlips = flipsSmart;
        result.smart.alarmLatencyS = latSmart;
        result.smart.finalStatus = rSmart.finalStatus;

        result.conventional.rmse_m = rmseConv;
        result.conventional.falseAlarmFlips = flipsConv;
        result.conventional.alarmLatencyS = latConv;
        result.conventional.finalStatus = rConv.finalStatus;

        result.rSmart = rSmart;
        result.rConv  = rConv;
        result.truth  = truth;
        result.time   = t;

        printSummary(result);
        if doPlot
            try, plotComparison(result); catch pe, fprintf('Plot skipped: %s\n', pe.message); end
        end
    catch e
        result.ok = false; result.error = e.message;
        fprintf('[compare_conventional_vs_smart] FAILED: %s\n', e.message);
    end
end

function rConv = simulate_conventional_radar(p, N)
    if nargin<2, N = round(p.Tsim / p.dt) + 1; end
    t = (0:N-1) * p.dt;
    truth = trueWaterLevel_local(t, p.scenario, p.rise_rate);

    levelRaw = zeros(1,N);
    state = zeros(1,N);
    for k = 1:N
        noiseStd = p.noiseStdMonitoring;
        levelRaw(k) = truth(k) + noiseStd*randn();
        if levelRaw(k) >= p.levelFlood
            state(k) = 2;
        elseif levelRaw(k) >= p.levelAlert
            state(k) = 1;
        else
            state(k) = 0;
        end
    end

    rConv.time = t;
    rConv.levelRaw = levelRaw;
    rConv.state = state;
    if state(end) == 2, rConv.finalStatus = 'flood_risk';
    elseif state(end) == 1, rConv.finalStatus = 'alert';
    else, rConv.finalStatus = 'monitoring';
    end
end

function n = count_flips(state)
    d = diff(state);
    n = sum(d < 0);
end

function lat = latency(t, idxTrue, idxDetect)
    if isempty(idxTrue) || isempty(idxDetect), lat = NaN;
    else, lat = t(idxDetect) - t(idxTrue);
    end
end

function truth = trueWaterLevel_local(t, scenario, riseRate)
    baseLevel = 0.5;
    switch lower(scenario)
        case 'stable',       truth = baseLevel * ones(size(t));
        case 'receding',     truth = max(baseLevel + 3 + riseRate.*t, 0);
        case 'flash_flood',  truth = baseLevel + 3./(1+exp(-0.25*(t-40)));
        otherwise,           truth = baseLevel + riseRate.*t;
    end
    truth = max(truth, 0);
end

function printSummary(r)
    fprintf('\n========= CONVENTIONAL vs SMART RADAR — %s =========\n', r.scenario);
    fprintf('%-28s %14s %14s\n', 'Metric', 'Conventional', 'Smart (ours)');
    fprintf('%-28s %13.3f m %13.3f m\n', 'RMSE vs ground truth', r.conventional.rmse_m, r.smart.rmse_m);
    fprintf('%-28s %13d   %13d  \n', 'False-alarm flips', r.conventional.falseAlarmFlips, r.smart.falseAlarmFlips);
    fprintf('%-28s %12.1f s %12.1f s\n', 'Alarm latency vs truth', r.conventional.alarmLatencyS, r.smart.alarmLatencyS);
    fprintf('%-28s %13s %13s\n', 'Final status', r.conventional.finalStatus, r.smart.finalStatus);
    fprintf('=====================================================================\n\n');
end

function plotComparison(r)
    figure('Name','Conventional vs Smart Radar','Color','w');
    subplot(2,1,1);
    plot(r.time, r.truth, 'k-', 'LineWidth', 1.5); hold on;
    plot(r.rConv.time, r.rConv.levelRaw, 'r:', 'LineWidth', 1.2);
    plot(r.rSmart.time, r.rSmart.waterLevelKalman, 'g-', 'LineWidth', 1.5);
    legend('Ground truth','Conventional (raw, noisy)','Smart (Kalman-filtered)');
    title(sprintf('%s: Level Tracking', r.scenario)); xlabel('Time (s)'); ylabel('Level (m)'); grid on;

    subplot(2,1,2);
    plot(r.rConv.time, r.rConv.state, 'r-', 'LineWidth', 1.5); hold on;
    plot(r.rSmart.time, r.rSmart.state, 'g-', 'LineWidth', 1.5);
    legend('Conventional state','Smart state');
    title('Alarm State Timeline (0=monitor,1=alert,2=flood)'); xlabel('Time (s)'); ylabel('State'); grid on;
end
