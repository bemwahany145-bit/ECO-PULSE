function [X, Y] = gen_training_data(p_base)
    scenarios = {'slow_rise','fast_rise','receding','flash_flood','stable'};
    horizon = 30;
    dt = 1;
    Tsim = 160;
    X = {}; Y = [];
    rng(99);
    for s = 1:numel(scenarios)
        for trial = 1:6
            p = get_params(scenarios{s});
            rainPeaks = [0 2 5 10 20 0];
            rainPeak = rainPeaks(mod(trial-1,6)+1);
            rainStart = 20 + 10*trial;
            levels = zeros(1,Tsim); rates = zeros(1,Tsim); rains = zeros(1,Tsim);
            prevLevel = NaN;
            for k = 1:Tsim
                t = k*dt;
                riseRate = p.rise_rate;
                if strcmpi(p.scenario,'stable')
                    lvl = 0.5;
                elseif strcmpi(p.scenario,'receding')
                    lvl = max(0.5 + 3 + riseRate*t, 0);
                elseif strcmpi(p.scenario,'flash_flood')
                    lvl = 0.5 + 3/(1+exp(-0.25*(t-40)));
                else
                    lvl = 0.5 + riseRate*t;
                end
                if isnan(prevLevel), rt = 0; else, rt = (lvl-prevLevel)/dt; end
                prevLevel = lvl;
                rain = rainPeak*max(0, sin(pi*(t-rainStart)/40)) * (t>rainStart && t<rainStart+40);
                levels(k) = lvl; rates(k) = rt; rains(k) = rain;
            end
            for t0 = 25:5:(Tsim-horizon)
                hist_idx = max(1,t0-19):t0;
                lvl_h = levels(hist_idx); rt_h = rates(hist_idx); rain_h = rains(hist_idx);
                tf = t0+horizon;
                riseRate = p.rise_rate;
                if strcmpi(p.scenario,'stable')
                    true_future = 0.5;
                elseif strcmpi(p.scenario,'receding')
                    true_future = max(0.5+3+riseRate*tf,0);
                elseif strcmpi(p.scenario,'flash_flood')
                    true_future = 0.5 + 3/(1+exp(-0.25*(tf-40)));
                else
                    true_future = 0.5 + riseRate*tf;
                end
                X{end+1} = [lvl_h; rt_h; rain_h];
                Y(end+1) = true_future;
            end
        end
    end
end
