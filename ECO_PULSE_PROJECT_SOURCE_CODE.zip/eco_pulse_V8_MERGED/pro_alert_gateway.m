function pro_alert_gateway(params, status, features)
    msg = sprintf('[Radar] %s · t=%.1fs · lvl=%.2fm · rate=%+.4fm/s', ...
        status, features.timestamp, features.waterLevel, features.rateOfRise);
    if getfield_or(params,'sms_enabled',false)
        fprintf('  [SMS]      %s\n', msg);
    end
    if getfield_or(params,'telegram_enabled',false)
        fprintf('  [TELEGRAM] %s\n', msg);
    end
    if getfield_or(params,'whatsapp_enabled',false)
        fprintf('  [WHATSAPP] %s\n', msg);
    end
    if getfield_or(params,'iot_enabled',true)
        proto = getfield_or(params,'iot_protocol','LoRa');
        fprintf('  [IoT/%s]  %s\n', proto, msg);
    end
end
function v = getfield_or(s,f,d), if isfield(s,f), v=s.(f); else, v=d; end; end
