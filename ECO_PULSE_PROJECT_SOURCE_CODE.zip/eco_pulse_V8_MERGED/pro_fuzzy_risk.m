function risk = pro_fuzzy_risk(features, params)
    L = features.waterLevel;
    R = features.rateOfRise;
    mu_L_lo = trap(L, [0 0 1.5 params.levelAlert]);
    mu_L_md = trap(L, [params.levelAlert-0.3 params.levelAlert ...
                       params.levelFlood params.levelFlood+0.3]);
    mu_L_hi = trap(L, [params.levelFlood-0.1 params.levelFlood 10 10]);
    mu_R_lo = trap(R, [-1 -1 0 params.rateAlert]);
    mu_R_md = trap(R, [params.rateAlert*0.5 params.rateAlert ...
                       params.rateFlood params.rateFlood*1.2]);
    mu_R_hi = trap(R, [params.rateFlood*0.8 params.rateFlood 1 1]);
    w_lo = max(mu_L_lo, mu_R_lo);
    w_md = max(mu_L_md, mu_R_md);
    w_hi = max([mu_L_hi, mu_R_hi, min(mu_L_md,mu_R_md)]);
    num = w_lo*0.15 + w_md*0.55 + w_hi*0.9;
    risk = min(max(num / (w_lo+w_md+w_hi+1e-9), 0), 1);
end
function y = trap(x, p)
    a=p(1);b=p(2);c=p(3);d=p(4);
    if x<=a||x>=d, y=0;
    elseif x<b, y=(x-a)/max(b-a,1e-9);
    elseif x<=c, y=1;
    else, y=(d-x)/max(d-c,1e-9);
    end
end
