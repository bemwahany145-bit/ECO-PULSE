function [xEst, state] = kalman_tracker(z, dt, state, doppler_meas, params)

    if nargin < 4, doppler_meas = []; end
    if nargin < 5, params = struct(); end

    if isempty(state)
        state.x = [z; 0];
        state.P = diag([1 0.01]);
        state.Q = diag([1e-4 1e-6]);
        state.R = 0.01;
    end

    F = [1 dt; 0 1];

    x = F * state.x;
    P = F * state.P * F' + state.Q;

    use_doppler = ~isempty(doppler_meas) && isfinite(doppler_meas) && ...
                  getfield_or(params,'kalman_use_doppler',true);

    if use_doppler
        H = [1 0; 0 1];
        R_doppler = getfield_or(params,'kalman_R_doppler',0.5);
        R = diag([state.R, R_doppler]);
        z_vec = [z; doppler_meas];

        y = z_vec - H*x;
        S = H*P*H' + R;
        K = P*H'/S;
        x = x + K*y;
        P = (eye(2) - K*H) * P;
    else
        H = [1 0];
        y = z - H*x;
        S = H*P*H' + state.R;
        K = P*H'/S;
        x = x + K*y;
        P = (eye(2) - K*H) * P;
    end

    state.x = x;
    state.P = P;
    xEst = x;
end

function v = getfield_or(s,f,d)
    if isstruct(s) && isfield(s,f), v = s.(f); else, v = d; end
end
