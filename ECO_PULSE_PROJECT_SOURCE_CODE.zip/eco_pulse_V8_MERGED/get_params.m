function params = get_params(scenarioOrConfig)

    if nargin < 1, scenarioOrConfig = 'slow_rise'; end

    params.dt   = 1;
    params.Tsim = 160;

    params.mountHeight     = 15;
    params.samplesPerMeter = 8;

    params.levelAlert = 2.5;
    params.levelFlood = 3.0;

    params.rateAlert = 0.020;
    params.rateFlood = 0.040;

    params.snrThreshold = 6;

    params.persistenceWindow = 30;
    params.persistenceCount  = 3;

    params.noiseStdMonitoring = 0.05;
    params.noiseStdAlert      = 0.04;
    params.clutterLevel       = 0.08;
    params.SNR_dB             = 15;
    params.clutter_dB         = -5;
    params.multipath          = true;

    params.fs                        = 1e4;
    params.pulse_repetition_interval = 20e-3;

    params.num_pulses = 20;

    params.duty_cycle  = 0.05;
    params.zc_root     = 5;
    params.zc_length   = 127;
    params.chirp_bandwidth = 20e6;
    params.chirp_duration  = 20e-6;

    params.f0                 = 24e9;
    params.enable_passband    = false;
    params.frequency_agility  = true;
    params.freq_hop_set       = [-1 -0.5 0 0.5 1]*2e3;
    params.window_type        = 'hann';
    params.window_param       = 60;
    params.bursts_per_frame   = 1;
    params.gap_between_bursts = 0;
    params.code_type          = 'none';
    params.barker_length      = 13;
    params.frank_M            = 4;

    params.scenario         = 'slow_rise';
    params.wave_spectrum    = 'pierson_moskowitz';
    params.wind_speed_U10   = 6;
    params.enable_doppler   = true;
    params.lambda           = 3e8 / 24e9;
    params.bank_multipath   = true;
    params.bank_offset_m    = 8;

    params.colored_noise    = false;
    params.color_alpha      = 0.9;
    params.rain_rate_mmph   = 0;
    params.rain_k           = 0.0001;
    params.rain_alpha_exp   = 1.0;

    params.enable_range_doppler = true;
    params.cfar_enabled         = true;
    params.cfar_type            = '2STAGE';
    params.cfar_Pfa             = 1e-6;
    params.cfar_train_cells     = 32;
    params.cfar_guard_cells     = 4;
    params.kalman_enabled       = true;
    params.kalman_use_doppler   = true;
    params.kalman_R_doppler     = 0.3;
    params.eigen_snr_enabled    = false;
    params.mti_order            = 2;
    params.super_resolution     = 'none';
    params.sr_num_targets       = 1;

    params.forecast_enabled      = true;
    params.forecast_horizon_s    = 30;
    params.forecast_history_s    = 30;
    params.ml_classifier_enabled = true;
    params.ml_model_path         = '';
    params.rain_forecast_enabled = true;
    params.rain_to_rise_coeff    = 0.001;
    params.forecast_early_warning = true;
    params.forecaster_type        = 'arima';

    params.energy_adaptive_enabled = true;
    params.energy.P_zc           = 0.1;
    params.energy.P_chirp        = 0.3;
    params.energy_calm_duty        = 0.6;
    params.energy_low_battery_pct  = 20;
    params.energy_low_battery_duty = 0.5;
    params.energy_risk_threshold   = 0.6;

    params.range_estimation_mode = 'ground_truth';
    params.track_gate_width_m    = 2.0;

    params.verbose = false;
    params.solar_panel_W           = 30;
    params.battery_capacity_Wh     = 50;

    params.autosave_mat_file = 'rx_matrix_data.mat';
    params.autosave_enabled  = true;

    params.use_gui            = false;
    params.show_countdown     = true;
    params.show_risk_curve    = true;
    params.show_range_doppler = true;
    params.export_report      = false;
    params.report_file        = 'flood_report.pdf';
    params.use_3d_fog         = true;
    params.use_big_indicators = true;
    params.use_stl_radar      = false;
    params.stl_radar_file     = 'tower.stl';
    params.use_tabs           = true;
    params.use_topo_map       = false;

    params.mc_runs      = 0;
    params.mc_seed_base = 42;
    params.weather_file = '';
    params.raytracing   = false;

    params.rateWindow = params.samplesPerMeter;
    params.dt_rate    = params.samplesPerMeter * params.dt;

    if ischar(scenarioOrConfig) || isstring(scenarioOrConfig)
        params.scenario = char(scenarioOrConfig);
    elseif isstruct(scenarioOrConfig)
        params = mergeStructs(params, scenarioOrConfig);
    end

    switch lower(params.scenario)
        case 'stable',      params.rise_rate = 0.0;
        case 'slow_rise',   params.rise_rate = 0.025;
        case 'fast_rise',   params.rise_rate = 0.08;
        case 'receding',    params.rise_rate = -0.015;
        case 'flash_flood', params.rise_rate = 0.15;
        otherwise,          params.rise_rate = 0.025;
    end

    if isfield(params,'f0') && params.f0 > 0
        params.lambda = 3e8 / params.f0;
    end
end

function a = mergeStructs(a, b)
    if ~isstruct(b), return; end
    fn = fieldnames(b);
    for i = 1:numel(fn)
        k = fn{i};
        if isfield(a,k) && isstruct(a.(k)) && isstruct(b.(k))
            a.(k) = mergeStructs(a.(k), b.(k));
        else
            a.(k) = b.(k);
        end
    end
end
