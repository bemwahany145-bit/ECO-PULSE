function report = run_full_validation(nRepeats)

    if nargin<1, nRepeats = 8; end
    report = struct();
    fprintf('\n#####################################################\n');
    fprintf('#  FULL VALIDATION SUITE\n');
    fprintf('#####################################################\n');

    fprintf('\n--- [1/4] Baseline vs Green across all 5 scenarios ---\n');
    scenarios = {'stable','slow_rise','fast_rise','receding','flash_flood'};
    sweep = struct('scenario',{},'energySavedPct',{},'qualityDeltaPct',{},'ok',{});
    for i = 1:numel(scenarios)
        try
            cmp = compare_baseline_vs_green(scenarios{i}, false);
            sweep(i).scenario         = scenarios{i};
            sweep(i).energySavedPct   = cmp.kpi.energySavedPct;
            sweep(i).qualityDeltaPct  = cmp.kpi.qualityDeltaPct;
            sweep(i).ok = cmp.ok;
        catch e
            sweep(i).scenario = scenarios{i}; sweep(i).ok = false;
            sweep(i).energySavedPct = NaN; sweep(i).qualityDeltaPct = NaN;
            fprintf('  %-12s FAILED: %s\n', scenarios{i}, e.message);
        end
    end
    report.sweep = sweep;
    okMask = [sweep.ok];
    fprintf('  Scenarios OK: %d/%d.  Energy saved range: %.1f%% to %.1f%%.  Quality delta range: %.2f to %.2f pct-pts.\n', ...
        sum(okMask), numel(sweep), min([sweep(okMask).energySavedPct]), max([sweep(okMask).energySavedPct]), ...
        min([sweep(okMask).qualityDeltaPct]), max([sweep(okMask).qualityDeltaPct]));

    fprintf('\n--- [2/4] Statistical repetition (scenario=slow_rise, %d repeats, independent noise draws) ---\n', nRepeats);
    try
        savedPct = zeros(nRepeats,1);
        for r = 1:nRepeats
            pB = get_params('slow_rise'); pB.energy_adaptive_enabled = false;
            pG = get_params('slow_rise'); pG.energy_adaptive_enabled = true;
            seed = 5000 + r*97;
            rng(seed); rB = main_flood_monitoring_system_core(pB);
            rng(seed); rG = main_flood_monitoring_system_core(pG);
            savedPct(r) = 100*(rB.energyUsedJ(end) - rG.energyUsedJ(end))/max(rB.energyUsedJ(end),eps);
        end
        report.repeat.savedPctMean = mean(savedPct);
        report.repeat.savedPctStd  = std(savedPct);
        report.repeat.n            = nRepeats;
        fprintf('  Energy saved: %.2f%% +/- %.2f%% (n=%d) -> %s\n', ...
            report.repeat.savedPctMean, report.repeat.savedPctStd, nRepeats, ...
            ternary_str(report.repeat.savedPctStd < 0.3*abs(report.repeat.savedPctMean), ...
                'STABLE pattern (low variance relative to mean)', ...
                'HIGH VARIANCE - inspect before presenting as a fixed number'));
    catch e
        fprintf('  FAILED: %s\n', e.message);
        report.repeat = struct('savedPctMean',NaN,'savedPctStd',NaN,'n',nRepeats);
    end

    fprintf('\n--- [3/4] Efficiency-vs-quality tradeoff curve (scenario=slow_rise) ---\n');
    try
        calmDuties = [0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0];
        curve = struct('calmDuty',{},'energySavedPct',{},'qualityPct',{});
        seed = 7777;
        pB = get_params('slow_rise'); pB.energy_adaptive_enabled = false;
        rng(seed); rB = main_flood_monitoring_system_core(pB);
        eB = rB.energyUsedJ(end);
        for j = 1:numel(calmDuties)
            pG = get_params('slow_rise'); pG.energy_adaptive_enabled = true;
            pG.energy_calm_duty = calmDuties(j);
            rng(seed); rG = main_flood_monitoring_system_core(pG);
            eG = rG.energyUsedJ(end);
            kG = compute_kpi_summary(rG, pG);
            curve(j).calmDuty        = calmDuties(j);
            curve(j).energySavedPct  = 100*(eB-eG)/max(eB,eps);
            curve(j).qualityPct      = kG.detectionRatePct;
            fprintf('  calm_duty=%.1f  ->  energy saved=%5.1f%%   detection-rate=%.1f%%\n', ...
                calmDuties(j), curve(j).energySavedPct, curve(j).qualityPct);
        end
        report.tradeoffCurve = curve;
        fprintf('  Current default (energy_calm_duty=0.6) is a mid-curve, documented choice - see table above.\n');
    catch e
        fprintf('  FAILED: %s\n', e.message);
    end

    fprintf('\n--- [4/4] Stress test (degraded SNR / extreme params / no modules disabled) ---\n');
    stressResults = struct('name',{},'ok',{},'note',{});
    stressCases = {
        struct('name','very low SNR (SNR_dB -20)',              'mod', @(p) setfield(p,'SNR_dB',     p.SNR_dB - 20))
        struct('name','extreme rise rate (x5)',                 'mod', @(p) setfield(p,'rise_rate',   p.rise_rate*5))
        struct('name','zero duty cycle edge case',               'mod', @(p) setfield(p,'duty_cycle',  1e-6))
        struct('name','very short Tsim (10s)',                   'mod', @(p) setfield(p,'Tsim',        10))
        struct('name','very long Tsim (600s)',                   'mod', @(p) setfield(p,'Tsim',        600))
        struct('name','tight CFAR Pfa (1e-9)',                   'mod', @(p) setfield(p,'cfar_Pfa',    1e-9))
    };
    for c = 1:numel(stressCases)
        name = stressCases{c}.name; modFcn = stressCases{c}.mod;
        try
            p = get_params('fast_rise');
            p = modFcn(p);
            r = main_flood_monitoring_system_core(p);
            stressResults(c).name = name; stressResults(c).ok = true;
            stressResults(c).note = sprintf('completed, finalStatus=%s', r.finalStatus);
            fprintf('  PASS  %-40s %s\n', name, stressResults(c).note);
        catch e
            stressResults(c).name = name; stressResults(c).ok = false;
            stressResults(c).note = e.message;
            fprintf('  FAIL  %-40s %s\n', name, e.message);
        end
    end
    report.stress = stressResults;
    nOk = sum([stressResults.ok]);
    fprintf('  Stress test result: %d/%d cases completed without crashing.\n', nOk, numel(stressResults));

    fprintf('\n#####################################################\n');
    fprintf('#  VALIDATION SUITE COMPLETE\n');
    fprintf('#####################################################\n\n');
end

function s = ternary_str(cond, a, b)
    if cond, s = a; else, s = b; end
end
